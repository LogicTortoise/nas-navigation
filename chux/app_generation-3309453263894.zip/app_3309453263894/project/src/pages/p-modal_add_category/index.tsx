

import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

interface CategoryFormData {
  name: string;
  icon: string;
}

const AddCategoryModal: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<CategoryFormData>({
    name: '',
    icon: 'fa-folder'
  });
  const [nameError, setNameError] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const categoryNameInputRef = useRef<HTMLInputElement>(null);

  // 预设图标列表
  const iconList = [
    'fa-folder', 'fa-briefcase', 'fa-graduation-cap', 'fa-pen-nib', 'fa-gamepad',
    'fa-heart', 'fa-star', 'fa-book', 'fa-music', 'fa-video',
    'fa-image', 'fa-code', 'fa-globe', 'fa-shopping-cart', 'fa-home',
    'fa-users', 'fa-cog', 'fa-chart-bar', 'fa-calendar', 'fa-envelope',
    'fa-file-alt', 'fa-search', 'fa-download', 'fa-upload', 'fa-share',
    'fa-link', 'fa-bookmark', 'fa-tag', 'fa-folder-open', 'fa-archive'
  ];

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '添加分类 - 酷站导航';
    return () => {
      document.title = originalTitle;
    };
  }, []);

  // 页面加载时聚焦到输入框
  useEffect(() => {
    if (categoryNameInputRef.current) {
      categoryNameInputRef.current.focus();
    }
  }, []);

  // 处理输入框变化
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setFormData(prev => ({ ...prev, name: value }));
    
    // 清除错误信息
    if (nameError && value.trim()) {
      setNameError('');
    }
  };

  // 选择图标
  const handleIconSelect = (iconClass: string) => {
    setFormData(prev => ({ ...prev, icon: iconClass }));
  };

  // 表单验证
  const validateForm = (): boolean => {
    const trimmedName = formData.name.trim();
    
    if (!trimmedName) {
      setNameError('分类名称不能为空');
      if (categoryNameInputRef.current) {
        categoryNameInputRef.current.focus();
      }
      return false;
    }
    
    if (trimmedName.length > 20) {
      setNameError('分类名称不能超过20个字符');
      if (categoryNameInputRef.current) {
        categoryNameInputRef.current.focus();
      }
      return false;
    }
    
    setNameError('');
    return true;
  };

  // 保存分类
  const handleSaveCategory = async (e?: React.FormEvent) => {
    if (e) {
      e.preventDefault();
    }
    
    if (!validateForm()) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // 模拟保存操作
      console.log('保存分类:', {
        name: formData.name.trim(),
        icon: formData.icon
      });
      
      // 模拟异步操作
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // 显示成功提示
      alert('分类添加成功！');
      
      // 关闭弹窗并返回
      handleCloseModal();
    } catch (error) {
      console.error('保存失败:', error);
      alert('保存失败，请重试');
    } finally {
      setIsSubmitting(false);
    }
  };

  // 关闭弹窗
  const handleCloseModal = () => {
    navigate(-1);
  };

  // 处理遮罩点击
  const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      handleCloseModal();
    }
  };

  // 处理键盘事件
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleCloseModal();
      } else if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSaveCategory();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [formData]);

  return (
    <div className={styles.pageWrapper}>
      {/* 背景遮罩，用于提升文字可读性 */}
      <div className="fixed inset-0 bg-gradient-to-br from-indigo-100/30 to-purple-100/30 pointer-events-none z-0"></div>

      {/* 模态弹窗遮罩 */}
      <div 
        className={`fixed inset-0 bg-black/40 backdrop-blur-sm z-50 ${styles.modalOverlay}`}
        onClick={handleOverlayClick}
      >
        {/* 模态弹窗内容 */}
        <div className={`absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full max-w-md mx-4 ${styles.modalContent}`}>
          
          {/* 弹窗主体 */}
          <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
            
            {/* 弹窗头部 */}
            <div className="flex items-center justify-between p-6 border-b border-slate-200">
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center mr-3">
                  <i className="fa-solid fa-folder-plus text-primary"></i>
                </div>
                <h2 className="text-xl font-bold text-slate-800">添加分类</h2>
              </div>
              <button 
                onClick={handleCloseModal}
                className="text-slate-400 hover:text-slate-600 transition-colors p-1 rounded-lg hover:bg-slate-100"
              >
                <i className="fa-solid fa-xmark text-xl"></i>
              </button>
            </div>

            {/* 弹窗内容区 */}
            <div className="p-6">
              
              <form onSubmit={handleSaveCategory} className="space-y-6">
                
                {/* 分类名称 */}
                <div className="space-y-2">
                  <label htmlFor="category-name" className="block text-sm font-medium text-slate-700">
                    分类名称 <span className="text-accent">*</span>
                  </label>
                  <input 
                    ref={categoryNameInputRef}
                    type="text" 
                    id="category-name" 
                    name="category-name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-3 rounded-lg border border-slate-300 ${styles.formInput} bg-white/80 backdrop-blur-sm ${nameError ? 'border-accent' : ''}`}
                    placeholder="请输入分类名称"
                    maxLength={20}
                  />
                  {nameError && (
                    <p className="text-sm text-accent">{nameError}</p>
                  )}
                  <p className="text-xs text-slate-400">最多20个字符</p>
                </div>

                {/* 选择图标 */}
                <div className="space-y-3">
                  <label className="block text-sm font-medium text-slate-700">选择图标</label>
                  
                  {/* 图标选择器 */}
                  <div className={`${styles.iconSelector} p-3 bg-slate-50 rounded-lg border border-slate-200`}>
                    {iconList.map(iconClass => (
                      <div
                        key={iconClass}
                        className={`${styles.iconOption} ${formData.icon === iconClass ? styles.selected : ''}`}
                        onClick={() => handleIconSelect(iconClass)}
                      >
                        <i className={`fa-solid ${iconClass} text-lg`}></i>
                      </div>
                    ))}
                  </div>
                  
                  {/* 当前选中的图标预览 */}
                  <div className="flex items-center space-x-3 p-3 bg-primary/5 rounded-lg border border-primary/20">
                    <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center text-white">
                      <i className={`fa-solid ${formData.icon} text-lg`}></i>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-slate-800">当前图标</p>
                      <p className="text-xs text-slate-500">点击选择其他图标</p>
                    </div>
                  </div>
                </div>

              </form>
            </div>

            {/* 弹窗底部 */}
            <div className="flex items-center justify-end space-x-3 p-6 border-t border-slate-200 bg-slate-50/50">
              <button 
                type="button" 
                onClick={handleCloseModal}
                className={`px-6 py-2.5 rounded-lg ${styles.btnSecondary} font-medium`}
              >
                取消
              </button>
              <button 
                type="button" 
                onClick={handleSaveCategory}
                disabled={isSubmitting}
                className={`px-6 py-2.5 rounded-lg ${styles.btnPrimary} font-medium shadow-lg shadow-indigo-500/20 disabled:opacity-50 disabled:cursor-not-allowed`}
              >
                <i className="fa-solid fa-check mr-2"></i>
                {isSubmitting ? '保存中...' : '保存分类'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddCategoryModal;

