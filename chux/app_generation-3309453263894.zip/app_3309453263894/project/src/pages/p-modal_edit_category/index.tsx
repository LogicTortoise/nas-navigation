

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './styles.module.css';
import { Category, IconOption } from './types';

const ModalEditCategory: React.FC = () => {
  const navigate = useNavigate();

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '管理分类 - 酷站导航';
    return () => { document.title = originalTitle; };
  }, []);

  // 分类数据状态
  const [categories, setCategories] = useState<Category[]>([
    { id: 1, name: '工作效率', icon: 'briefcase', siteCount: 12, color: 'blue' },
    { id: 2, name: '学习充电', icon: 'graduation-cap', siteCount: 8, color: 'green' },
    { id: 3, name: '设计灵感', icon: 'pen-nib', siteCount: 15, color: 'purple' },
    { id: 4, name: '娱乐摸鱼', icon: 'gamepad', siteCount: 6, color: 'orange' },
  ]);

  // 编辑状态
  const [editingCategoryId, setEditingCategoryId] = useState<number | null>(null);
  const [editFormData, setEditFormData] = useState<{ [key: number]: { name: string; icon: string } }>({});

  // 图标选项
  const iconOptions: IconOption[] = [
    { icon: 'briefcase', class: 'fa-briefcase' },
    { icon: 'graduation-cap', class: 'fa-graduation-cap' },
    { icon: 'pen-nib', class: 'fa-pen-nib' },
    { icon: 'gamepad', class: 'fa-gamepad' },
    { icon: 'music', class: 'fa-music' },
    { icon: 'camera', class: 'fa-camera' },
    { icon: 'book', class: 'fa-book' },
    { icon: 'heart', class: 'fa-heart' },
  ];

  // 关闭弹窗
  const handleCloseModal = () => {
    navigate(-1);
  };

  // 点击遮罩关闭弹窗
  const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      handleCloseModal();
    }
  };

  // ESC键关闭弹窗
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleCloseModal();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  // 编辑分类
  const handleEditCategory = (categoryId: number) => {
    const category = categories.find(c => c.id === categoryId);
    if (category) {
      setEditFormData(prev => ({
        ...prev,
        [categoryId]: { name: category.name, icon: category.icon }
      }));
      setEditingCategoryId(categoryId);
    }
  };

  // 取消编辑
  const handleCancelEdit = () => {
    setEditingCategoryId(null);
  };

  // 选择图标
  const handleIconSelect = (categoryId: number, icon: string) => {
    setEditFormData(prev => ({
      ...prev,
      [categoryId]: { ...prev[categoryId], icon }
    }));
  };

  // 保存分类
  const handleSaveCategory = (categoryId: number) => {
    const formData = editFormData[categoryId];
    if (!formData?.name.trim()) {
      alert('请输入分类名称');
      return;
    }

    setCategories(prev => prev.map(cat => 
      cat.id === categoryId 
        ? { ...cat, name: formData.name, icon: formData.icon }
        : cat
    ));

    setEditingCategoryId(null);
    console.log(`分类 ${formData.name} 已更新`);
  };

  // 删除分类
  const handleDeleteCategory = (categoryId: number) => {
    const category = categories.find(c => c.id === categoryId);
    if (!category) return;

    if (confirm(`确定要删除分类"${category.name}"吗？删除后该分类下的所有网站链接将被移至"未分类"。`)) {
      setCategories(prev => prev.filter(cat => cat.id !== categoryId));
      console.log(`分类 ${category.name} 已删除`);
    }
  };

  // 添加新分类
  const handleAddCategory = () => {
    navigate('/modal-add-category');
  };

  // 获取分类颜色样式
  const getCategoryColorClasses = (color: string) => {
    const colorMap: { [key: string]: { bg: string; text: string } } = {
      blue: { bg: 'bg-blue-100', text: 'text-blue-600' },
      green: { bg: 'bg-green-100', text: 'text-green-600' },
      purple: { bg: 'bg-purple-100', text: 'text-purple-600' },
      orange: { bg: 'bg-orange-100', text: 'text-orange-600' },
    };
    return colorMap[color] || colorMap.blue;
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 背景遮罩 */}
      <div className="fixed inset-0 bg-gradient-to-br from-indigo-100/30 to-purple-100/30 pointer-events-none z-0"></div>

      {/* 模态弹窗遮罩 */}
      <div 
        className={`fixed inset-0 ${styles.modalOverlay} z-50 flex items-center justify-center p-4`}
        onClick={handleOverlayClick}
      >
        {/* 弹窗内容 */}
        <div className={`${styles.modalContent} rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden ${styles.fadeIn}`}>
          
          {/* 弹窗头部 */}
          <div className="flex items-center justify-between p-6 border-b border-glassBorder">
            <h2 className="text-xl font-bold text-slate-800 flex items-center">
              <i className="fa-solid fa-folder-tree text-primary mr-3"></i>
              管理分类
            </h2>
            <button 
              onClick={handleCloseModal}
              className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <i className="fa-solid fa-xmark text-xl"></i>
            </button>
          </div>

          {/* 弹窗主体内容 */}
          <div className="p-6 overflow-y-auto max-h-[calc(90vh-140px)]">
            
            {/* 分类列表 */}
            <div className="space-y-3 mb-6">
              {categories.map((category) => {
                const colorClasses = getCategoryColorClasses(category.color);
                const isEditing = editingCategoryId === category.id;
                const formData = editFormData[category.id] || { name: category.name, icon: category.icon };

                return (
                  <div key={category.id} className={`${styles.categoryItem} ${styles.glassCard} rounded-xl p-4`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className={`w-10 h-10 rounded-lg ${colorClasses.bg} ${colorClasses.text} flex items-center justify-center mr-3`}>
                          <i className={`fa-solid fa-${category.icon} text-lg`}></i>
                        </div>
                        <div>
                          <h3 className="font-medium text-slate-800">{category.name}</h3>
                          <p className="text-sm text-slate-500">{category.siteCount} 个网站</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button 
                          onClick={() => handleEditCategory(category.id)}
                          className="p-2 text-slate-400 hover:text-primary hover:bg-primary/10 rounded-lg transition-colors"
                        >
                          <i className="fa-solid fa-edit text-sm"></i>
                        </button>
                        <button 
                          onClick={() => handleDeleteCategory(category.id)}
                          className="p-2 text-slate-400 hover:text-accent hover:bg-accent/10 rounded-lg transition-colors"
                        >
                          <i className="fa-solid fa-trash text-sm"></i>
                        </button>
                      </div>
                    </div>
                    
                    {/* 编辑表单 */}
                    <div className={`${styles.editForm} ${isEditing ? styles.editFormExpanded : ''} mt-4 border-t border-slate-200 pt-4`}>
                      <form className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-slate-700 mb-2">分类名称</label>
                          <input 
                            type="text" 
                            value={formData.name}
                            onChange={(e) => setEditFormData(prev => ({
                              ...prev,
                              [category.id]: { ...prev[category.id], name: e.target.value }
                            }))}
                            className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-all"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-slate-700 mb-2">选择图标</label>
                          <div className={styles.iconSelector}>
                            {iconOptions.map((option) => (
                              <div 
                                key={option.icon}
                                onClick={() => handleIconSelect(category.id, option.icon)}
                                className={`${styles.iconOption} ${formData.icon === option.icon ? styles.iconOptionSelected : ''}`}
                              >
                                <i className={`fa-solid ${option.class}`}></i>
                              </div>
                            ))}
                          </div>
                        </div>
                        <div className="flex space-x-3 pt-2">
                          <button 
                            type="button" 
                            onClick={handleCancelEdit}
                            className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-800 transition-colors"
                          >
                            取消
                          </button>
                          <button 
                            type="button" 
                            onClick={() => handleSaveCategory(category.id)}
                            className="px-4 py-2 text-sm font-medium bg-primary text-white rounded-lg hover:bg-primaryHover transition-colors"
                          >
                            保存
                          </button>
                        </div>
                      </form>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* 添加新分类 */}
            <div 
              onClick={handleAddCategory}
              className="border-2 border-dashed border-slate-300 rounded-xl p-6 text-center hover:border-primary hover:bg-primary/5 transition-colors cursor-pointer"
            >
              <button className="w-full flex flex-col items-center justify-center text-slate-400 hover:text-primary">
                <i className="fa-solid fa-plus text-2xl mb-2"></i>
                <span className="text-sm font-medium">添加新分类</span>
              </button>
            </div>
          </div>

          {/* 弹窗底部 */}
          <div className="flex items-center justify-end p-6 border-t border-glassBorder bg-slate-50/50">
            <button 
              onClick={handleCloseModal}
              className="px-6 py-2 text-slate-600 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors font-medium"
            >
              关闭
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ModalEditCategory;

