

export interface Category {
  id: number;
  name: string;
  icon: string;
  siteCount: number;
  color: string;
}

export type IconOption = {
  icon: string;
  class: string;
};

