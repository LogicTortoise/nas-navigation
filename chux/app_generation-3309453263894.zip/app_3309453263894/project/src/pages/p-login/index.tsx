

import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

interface LoginFormData {
  email: string;
  password: string;
  rememberMe: boolean;
}

interface FormErrors {
  email: string;
  password: string;
}

export default function LoginPage() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<LoginFormData>({
    email: '',
    password: '',
    rememberMe: false
  });
  const [formErrors, setFormErrors] = useState<FormErrors>({
    email: '',
    password: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '用户登录 - 酷站导航';
    return () => { document.title = originalTitle; };
  }, []);

  // 页面加载时检查记住密码状态
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const rememberMe = localStorage.getItem('rememberMe') === 'true';
      const rememberedEmail = localStorage.getItem('rememberedEmail');
      
      if (rememberMe && rememberedEmail) {
        setFormData(prev => ({
          ...prev,
          email: rememberedEmail,
          rememberMe: true
        }));
      }
    }
  }, []);

  // 表单验证函数
  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const showError = (field: keyof FormErrors, message: string) => {
    setFormErrors(prev => ({
      ...prev,
      [field]: message
    }));
  };

  const hideError = (field: keyof FormErrors) => {
    setFormErrors(prev => ({
      ...prev,
      [field]: ''
    }));
  };

  // 处理输入框变化
  const handleInputChange = (field: keyof LoginFormData, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
    
    // 清除对应字段的错误
    if (field === 'email' || field === 'password') {
      hideError(field);
    }
  };

  // 处理输入框失焦验证
  const handleEmailBlur = () => {
    const email = formData.email.trim();
    if (email && !validateEmail(email)) {
      showError('email', '请输入有效的邮箱地址');
    } else {
      hideError('email');
    }
  };

  const handlePasswordBlur = () => {
    const password = formData.password.trim();
    if (!password) {
      showError('password', '密码不能为空');
    } else {
      hideError('password');
    }
  };

  // 密码显示/隐藏切换
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  // 表单提交处理
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const email = formData.email.trim();
    const password = formData.password.trim();
    const rememberMe = formData.rememberMe;
    
    let hasErrors = false;
    
    // 验证邮箱
    if (!email) {
      showError('email', '请输入邮箱地址');
      hasErrors = true;
    } else if (!validateEmail(email)) {
      showError('email', '请输入有效的邮箱地址');
      hasErrors = true;
    } else {
      hideError('email');
    }
    
    // 验证密码
    if (!password) {
      showError('password', '请输入密码');
      hasErrors = true;
    } else {
      hideError('password');
    }
    
    if (hasErrors) {
      return;
    }
    
    // 显示加载状态
    setIsLoading(true);
    
    // 模拟登录请求
    setTimeout(() => {
      // 保存记住密码状态
      if (typeof window !== 'undefined') {
        if (rememberMe) {
          localStorage.setItem('rememberedEmail', email);
          localStorage.setItem('rememberMe', 'true');
        } else {
          localStorage.removeItem('rememberedEmail');
          localStorage.removeItem('rememberMe');
        }
      }
      
      // 登录成功，跳转到首页
      navigate('/home');
    }, 1500);
  };

  // 键盘快捷键支持
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl/Cmd + Enter 提交表单
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        const form = document.getElementById('login-form') as HTMLFormElement;
        if (form) {
          form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  return (
    <div className={styles.pageWrapper}>
      {/* 背景遮罩，用于提升文字可读性 */}
      <div className="fixed inset-0 bg-gradient-to-br from-indigo-100/30 to-purple-100/30 pointer-events-none z-0"></div>

      {/* 主登录容器 */}
      <div className={`relative z-10 w-full max-w-md ${styles.animateFadeIn}`}>
        
        {/* Logo 区域 */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-tr from-primary to-purple-500 flex items-center justify-center text-white shadow-xl">
            <i className="fa-solid fa-compass text-2xl"></i>
          </div>
          <h1 className="text-2xl font-bold text-slate-800 mb-2">酷站导航</h1>
          <p className="text-slate-500">您的专属数字生活入口</p>
        </div>

        {/* 登录表单卡片 */}
        <div className={`${styles.glassCard} rounded-2xl shadow-2xl p-8`}>
          <div className="text-center mb-6">
            <h2 className="text-xl font-bold text-slate-800 mb-2">用户登录</h2>
            <p className="text-slate-500 text-sm">欢迎回来，请登录您的账户</p>
          </div>

          {/* 登录表单 */}
          <form id="login-form" className="space-y-6" onSubmit={handleSubmit}>
            
            {/* 邮箱输入框 */}
            <div className="space-y-2">
              <label htmlFor="email" className="block text-sm font-medium text-slate-700">
                <i className="fa-solid fa-envelope mr-2 text-slate-400"></i>邮箱地址
              </label>
              <input 
                type="email" 
                id="email" 
                name="email" 
                className={`w-full px-4 py-3 rounded-xl border border-slate-300 bg-white/60 backdrop-blur-sm ${styles.formInputFocus} transition-all ${formErrors.email ? 'border-accent' : ''}`}
                placeholder="请输入您的邮箱地址"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                onBlur={handleEmailBlur}
                required
              />
              {formErrors.email && (
                <div className={`${styles.errorMessage} ${styles.show}`}>{formErrors.email}</div>
              )}
            </div>

            {/* 密码输入框 */}
            <div className="space-y-2">
              <label htmlFor="password" className="block text-sm font-medium text-slate-700">
                <i className="fa-solid fa-lock mr-2 text-slate-400"></i>密码
              </label>
              <div className="relative">
                <input 
                  type={showPassword ? 'text' : 'password'}
                  id="password" 
                  name="password" 
                  className={`w-full px-4 py-3 pr-12 rounded-xl border border-slate-300 bg-white/60 backdrop-blur-sm ${styles.formInputFocus} transition-all ${formErrors.password ? 'border-accent' : ''}`}
                  placeholder="请输入您的密码"
                  value={formData.password}
                  onChange={(e) => handleInputChange('password', e.target.value)}
                  onBlur={handlePasswordBlur}
                  required
                />
                <button 
                  type="button" 
                  className="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-400 hover:text-slate-600 transition-colors"
                  onClick={togglePasswordVisibility}
                >
                  <i className={`fa-solid ${showPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                </button>
              </div>
              {formErrors.password && (
                <div className={`${styles.errorMessage} ${styles.show}`}>{formErrors.password}</div>
              )}
            </div>

            {/* 记住密码和忘记密码 */}
            <div className="flex items-center justify-between">
              <label className="flex items-center space-x-2 cursor-pointer">
                <input 
                  type="checkbox" 
                  id="remember-me" 
                  name="remember-me" 
                  className={`w-4 h-4 rounded border-slate-300 text-primary focus:ring-primary ${styles.checkboxCustom} transition-all`}
                  checked={formData.rememberMe}
                  onChange={(e) => handleInputChange('rememberMe', e.target.checked)}
                />
                <span className="text-sm text-slate-600">记住密码</span>
              </label>
              <Link 
                to="/forgot-password" 
                className={`text-sm text-slate-500 ${styles.linkHover} transition-colors`}
              >
                忘记密码？
              </Link>
            </div>

            {/* 登录按钮 */}
            <button 
              type="submit" 
              className={`w-full py-3 px-4 rounded-xl ${styles.btnPrimary} font-medium shadow-lg`}
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin mr-2"></i>
                  登录中...
                </>
              ) : (
                <>
                  <i className="fa-solid fa-sign-in-alt mr-2"></i>
                  登录
                </>
              )}
            </button>

            {/* 注册链接 */}
            <div className="text-center pt-4 border-t border-slate-200">
              <p className="text-sm text-slate-500">
                还没有账户？
                <Link 
                  to="/register" 
                  className={`text-primary font-medium ${styles.linkHover} transition-colors ml-1`}
                >
                  立即注册
                </Link>
              </p>
            </div>

          </form>
        </div>

        {/* 底部版权信息 */}
        <div className="text-center mt-8">
          <p className="text-xs text-slate-400">
            © 2024 酷站导航. 让每一次上网都从这里开始.
          </p>
        </div>

      </div>
    </div>
  );
}

