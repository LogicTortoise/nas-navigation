

import React, { useState, useEffect, useRef } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

interface ModalConfig {
  type: 'delete' | 'warning' | 'info' | 'success';
  title: string;
  subtitle: string;
  message: string;
  confirmText: string;
  cancelText: string;
  additionalInfo: string;
  details: string[];
}

const ModalConfirm: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [modalConfig, setModalConfig] = useState<ModalConfig>({
    type: 'delete',
    title: '操作确认',
    subtitle: '请确认您的操作',
    message: '确定要执行此操作吗？此操作无法撤销。',
    confirmText: '确认删除',
    cancelText: '取消',
    additionalInfo: '',
    details: []
  });
  const [isConfirmLoading, setIsConfirmLoading] = useState(false);
  const cancelButtonRef = useRef<HTMLButtonElement>(null);

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '操作确认 - 酷站导航';
    return () => { document.title = originalTitle; };
  }, []);

  // 解析URL参数并配置弹窗
  useEffect(() => {
    const params: Record<string, string> = {};
    searchParams.forEach((value, key) => {
      params[key] = decodeURIComponent(value);
    });

    const config = configureModal(params);
    setModalConfig(config);
  }, [searchParams]);

  // 自动聚焦到取消按钮
  useEffect(() => {
    if (cancelButtonRef.current) {
      cancelButtonRef.current.focus();
    }
  }, [modalConfig]);

  // 键盘事件处理
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleCancel();
      } else if (e.key === 'Enter' && !isConfirmLoading) {
        handleConfirm();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isConfirmLoading]);

  const configureModal = (params: Record<string, string>): ModalConfig => {
    let config: ModalConfig = {
      type: 'delete',
      title: '操作确认',
      subtitle: '请确认您的操作',
      message: '确定要执行此操作吗？此操作无法撤销。',
      confirmText: '确认删除',
      cancelText: '取消',
      additionalInfo: '',
      details: []
    };

    // 根据操作类型配置
    if (params.type) {
      switch(params.type) {
        case 'delete_link':
          config = {
            ...config,
            type: 'delete',
            title: '删除网站链接',
            subtitle: '删除确认',
            message: `确定要删除网站链接"${params.linkName || '该网站'}"吗？`,
            confirmText: '确认删除',
            cancelText: '取消'
          };
          break;
          
        case 'delete_category':
          config = {
            ...config,
            type: 'delete',
            title: '删除分类',
            subtitle: '危险操作',
            message: `确定要删除分类"${params.categoryName || '该分类'}"吗？`,
            confirmText: '确认删除',
            cancelText: '取消',
            additionalInfo: '此分类下有网站链接，删除后这些链接将无法恢复。',
            details: params.linkCount ? [`该分类下有 ${params.linkCount} 个网站链接`] : []
          };
          break;
          
        case 'delete_category_with_links':
          config = {
            ...config,
            type: 'warning',
            title: '删除分类及链接',
            subtitle: '危险操作',
            message: `确定要删除分类"${params.categoryName || '该分类'}"以及其中的所有网站链接吗？`,
            confirmText: '确认删除',
            cancelText: '取消',
            additionalInfo: '此操作将永久删除分类及其所有内容，无法撤销。',
            details: params.linkCount ? [`将删除 ${params.linkCount} 个网站链接`] : []
          };
          break;
          
        case 'warning':
          config = {
            ...config,
            type: 'warning',
            title: params.title || '警告',
            subtitle: params.subtitle || '重要提醒',
            message: params.message || '此操作可能产生不可预期的后果。',
            confirmText: params.confirmText || '继续',
            cancelText: params.cancelText || '取消'
          };
          break;
          
        case 'info':
          config = {
            ...config,
            type: 'info',
            title: params.title || '信息确认',
            subtitle: params.subtitle || '请确认',
            message: params.message || '请确认您要执行的操作。',
            confirmText: params.confirmText || '确认',
            cancelText: params.cancelText || '取消'
          };
          break;
      }
    }

    // 自定义参数覆盖
    if (params.title) config.title = params.title;
    if (params.subtitle) config.subtitle = params.subtitle;
    if (params.message) config.message = params.message;
    if (params.confirmText) config.confirmText = params.confirmText;
    if (params.cancelText) config.cancelText = params.cancelText;
    if (params.additionalInfo) config.additionalInfo = params.additionalInfo;

    return config;
  };

  const getModalIconAndStyle = () => {
    const iconClasses = {
      delete: 'fa-exclamation-triangle text-red-500',
      warning: 'fa-exclamation-circle text-yellow-500',
      info: 'fa-info-circle text-blue-500',
      success: 'fa-check-circle text-green-500'
    };

    const iconBgClasses = {
      delete: 'bg-red-100',
      warning: 'bg-yellow-100',
      info: 'bg-blue-100',
      success: 'bg-green-100'
    };

    const btnClasses = {
      delete: styles.btnDanger,
      warning: styles.btnWarning,
      info: styles.btnPrimary,
      success: styles.btnPrimary
    };

    return {
      iconClass: iconClasses[modalConfig.type] || iconClasses.delete,
      bgClass: iconBgClasses[modalConfig.type] || iconBgClasses.delete,
      btnClass: btnClasses[modalConfig.type] || btnClasses.delete
    };
  };

  const handleConfirm = () => {
    if (isConfirmLoading) return;

    setIsConfirmLoading(true);

    // 模拟处理延迟
    setTimeout(() => {
      const actionType = searchParams.get('type') || 'delete';
      console.log('确认操作:', actionType, searchParams);
      
      // 操作完成后跳转回首页
      navigate('/home');
    }, 800);
  };

  const handleCancel = () => {
    // 返回上一页
    navigate(-1);
  };

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      handleCancel();
    }
  };

  const handleButtonKeyDown = (e: React.KeyboardEvent<HTMLButtonElement>, direction: 'next' | 'prev') => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const buttons = [cancelButtonRef.current, document.querySelector('[data-confirm-btn]') as HTMLButtonElement, document.querySelector('[data-close-btn]') as HTMLButtonElement];
      const currentIndex = buttons.indexOf(e.target as HTMLButtonElement);
      const nextIndex = direction === 'next' ? 
        (currentIndex + 1) % buttons.length : 
        (currentIndex - 1 + buttons.length) % buttons.length;
      
      if (buttons[nextIndex]) {
        buttons[nextIndex].focus();
      }
    }
  };

  const { iconClass, bgClass, btnClass } = getModalIconAndStyle();

  return (
    <div className={styles.pageWrapper}>
      {/* 背景遮罩，用于提升文字可读性 */}
      <div className="fixed inset-0 bg-gradient-to-br from-indigo-100/30 to-purple-100/30 pointer-events-none z-0"></div>

      {/* 模态弹窗背景遮罩 */}
      <div 
        className={`fixed inset-0 ${styles.modalBackdrop} z-50 flex items-center justify-center animate-fade-in`}
        onClick={handleBackdropClick}
      >
        {/* 确认弹窗内容 */}
        <div className={`${styles.modalContent} rounded-2xl w-full max-w-md mx-4 animate-scale-in`}>
          
          {/* 弹窗头部 */}
          <div className="flex items-center justify-between p-6 pb-4">
            <div className="flex items-center">
              <div className={`w-12 h-12 rounded-full ${bgClass} flex items-center justify-center mr-4`}>
                <i className={`fa-solid ${iconClass.split(' ')[0]} ${iconClass.split(' ')[1]} text-xl`}></i>
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-800">{modalConfig.title}</h3>
                <p className="text-sm text-slate-500 mt-1">{modalConfig.subtitle}</p>
              </div>
            </div>
            <button 
              data-close-btn
              className="text-slate-400 hover:text-slate-600 transition-colors p-1"
              onClick={handleCancel}
              onKeyDown={(e) => handleButtonKeyDown(e, 'next')}
              tabIndex={0}
            >
              <i className="fa-solid fa-xmark text-xl"></i>
            </button>
          </div>

          {/* 弹窗内容区 */}
          <div className="px-6 pb-6">
            <div className="space-y-4">
              {/* 主要提示信息 */}
              <div className="text-slate-700 leading-relaxed">
                {modalConfig.message}
              </div>

              {/* 附加信息（可选） */}
              {modalConfig.additionalInfo && (
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                  <div className="flex items-start">
                    <i className="fa-solid fa-info-circle text-yellow-500 mt-0.5 mr-2"></i>
                    <div className="text-sm text-yellow-800">
                      <p>{modalConfig.additionalInfo}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* 详细信息列表（可选） */}
              {modalConfig.details && modalConfig.details.length > 0 && (
                <div className="space-y-2">
                  {modalConfig.details.map((detail, index) => (
                    <div key={index} className="flex items-center text-sm text-slate-600">
                      <i className="fa-solid fa-circle text-xs text-slate-400 mr-2"></i>
                      <span>{detail}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* 弹窗底部操作按钮 */}
          <div className="flex items-center justify-end space-x-3 px-6 pb-6">
            <button 
              ref={cancelButtonRef}
              className={`px-6 py-2.5 rounded-lg ${styles.btnSecondary} font-medium`}
              onClick={handleCancel}
              onKeyDown={(e) => handleButtonKeyDown(e, 'next')}
              tabIndex={0}
            >
              <i className="fa-solid fa-times mr-2"></i>
              {modalConfig.cancelText}
            </button>
            <button 
              data-confirm-btn
              className={`px-6 py-2.5 rounded-lg ${btnClass} font-medium`}
              onClick={handleConfirm}
              disabled={isConfirmLoading}
              onKeyDown={(e) => handleButtonKeyDown(e, 'prev')}
              tabIndex={0}
            >
              {isConfirmLoading ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin mr-2"></i>
                  处理中...
                </>
              ) : (
                <>
                  <i className="fa-solid fa-check mr-2"></i>
                  {modalConfig.confirmText}
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ModalConfirm;

