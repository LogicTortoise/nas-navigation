

import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import styles from './styles.module.css';

interface LinkData {
  name: string;
  url: string;
  category: string;
  icon: string;
}

const ModalEditLink: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  
  // 表单状态
  const [linkName, setLinkName] = useState('Dribbble');
  const [linkUrl, setLinkUrl] = useState('https://dribbble.com');
  const [linkCategory, setLinkCategory] = useState('design');
  const [previewIcon, setPreviewIcon] = useState('https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80');
  const [selectedIcon, setSelectedIcon] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  // 模拟链接数据
  const mockLinks: Record<string, LinkData> = {
    'link1': {
      name: 'Dribbble',
      url: 'https://dribbble.com',
      category: 'design',
      icon: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80'
    },
    'link2': {
      name: 'GitHub',
      url: 'https://github.com',
      category: 'work',
      icon: 'https://github.githubassets.com/favicons/favicon.svg'
    },
    'link3': {
      name: 'Notion',
      url: 'https://notion.so',
      category: 'work',
      icon: 'https://images.unsplash.com/photo-1611162616305-c69b3fa7fbe0?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80'
    }
  };

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '编辑网站链接 - 酷站导航';
    return () => {
      document.title = originalTitle;
    };
  }, []);

  // 加载链接数据
  useEffect(() => {
    const linkId = searchParams.get('linkId') || 'link1';
    const link = mockLinks[linkId];
    if (link) {
      setLinkName(link.name);
      setLinkUrl(link.url);
      setLinkCategory(link.category);
      setPreviewIcon(link.icon);
    }
  }, [searchParams]);

  // URL输入变化时自动获取图标
  const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const url = e.target.value.trim();
    setLinkUrl(url);
    
    if (url) {
      try {
        const faviconUrl = new URL(url).origin + '/favicon.ico';
        setPreviewIcon(faviconUrl);
      } catch (error) {
        // URL格式错误，保持原图标
      }
    }
  };

  // 图标选择
  const handleIconSelect = (iconClass: string) => {
    setSelectedIcon(iconClass);
    setPreviewIcon(''); // 清空图片图标，表示使用字体图标
  };

  // 上传图标
  const handleUploadIcon = () => {
    console.log('需要调用第三方接口实现文件上传功能');
    // 注释：此功能需要文件上传API，在原型阶段仅做UI展示
  };

  // 表单提交
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const formData = {
      name: linkName,
      url: linkUrl,
      category: linkCategory,
      icon: selectedIcon || previewIcon
    };
    
    console.log('保存链接数据:', formData);
    
    setIsSaving(true);
    
    // 模拟保存延迟
    setTimeout(() => {
      navigate('/home');
    }, 1000);
  };

  // 关闭模态框
  const handleClose = () => {
    navigate('/home');
  };

  // 处理背景点击
  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      handleClose();
    }
  };

  // 处理键盘事件
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleClose();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  // 预设图标选项
  const iconOptions = [
    { class: 'fas fa-globe', label: '地球' },
    { class: 'fas fa-star', label: '星星' },
    { class: 'fas fa-heart', label: '爱心' },
    { class: 'fas fa-lightbulb', label: '灯泡' },
    { class: 'fas fa-rocket', label: '火箭' }
  ];

  return (
    <div className={styles.pageWrapper}>
      {/* 背景遮罩，用于提升文字可读性 */}
      <div className="fixed inset-0 bg-gradient-to-br from-indigo-100/30 to-purple-100/30 pointer-events-none z-0"></div>

      {/* 模态弹窗背景遮罩 */}
      <div 
        className={`fixed inset-0 ${styles.modalBackdrop} z-50 flex items-center justify-center p-4`}
        onClick={handleBackdropClick}
      >
        {/* 编辑链接弹窗 */}
        <div 
          className={`${styles.modalContent} rounded-2xl shadow-2xl w-full max-w-md lg:max-w-lg p-6 ${styles.animateFadeInUp}`}
          onClick={(e) => e.stopPropagation()}
        >
          {/* 弹窗头部 */}
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-bold text-slate-800 flex items-center">
              <i className="fa-solid fa-edit text-primary mr-2"></i>
              编辑网站链接
            </h3>
            <button 
              onClick={handleClose}
              className="text-slate-400 hover:text-slate-600 transition-colors p-1 rounded-lg hover:bg-slate-100"
            >
              <i className="fa-solid fa-xmark text-xl"></i>
            </button>
          </div>
          
          {/* 编辑表单 */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* 网站图标预览 */}
            <div className="text-center mb-6">
              <div className={`${styles.iconPreview} mx-auto mb-2`}>
                {selectedIcon ? (
                  <i className={`${selectedIcon} text-2xl text-primary`}></i>
                ) : (
                  <img 
                    src={previewIcon}
                    alt="网站图标" 
                    className="w-8 h-8 object-contain"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80';
                    }}
                  />
                )}
              </div>
              <p className="text-sm text-slate-500">网站图标预览</p>
            </div>

            {/* 网站名称 */}
            <div>
              <label htmlFor="link-name" className="block text-sm font-medium text-slate-700 mb-2">
                <i className="fa-solid fa-tag text-primary mr-1"></i>
                网站名称 <span className="text-accent">*</span>
              </label>
              <input 
                type="text" 
                id="link-name" 
                name="link-name" 
                className={`w-full px-4 py-3 rounded-lg border border-slate-300 ${styles.formInputFocus} transition-all bg-white/80 backdrop-blur-sm`}
                placeholder="请输入网站名称"
                value={linkName}
                onChange={(e) => setLinkName(e.target.value)}
                required
              />
            </div>

            {/* 网站URL */}
            <div>
              <label htmlFor="link-url" className="block text-sm font-medium text-slate-700 mb-2">
                <i className="fa-solid fa-link text-primary mr-1"></i>
                网站 URL <span className="text-accent">*</span>
              </label>
              <input 
                type="url" 
                id="link-url" 
                name="link-url" 
                className={`w-full px-4 py-3 rounded-lg border border-slate-300 ${styles.formInputFocus} transition-all bg-white/80 backdrop-blur-sm`}
                placeholder="https://example.com"
                value={linkUrl}
                onChange={handleUrlChange}
                required
              />
              <p className="text-xs text-slate-500 mt-1">
                <i className="fa-info-circle mr-1"></i>
                输入URL后将自动获取网站图标
              </p>
            </div>

            {/* 所属分类 */}
            <div>
              <label htmlFor="link-category" className="block text-sm font-medium text-slate-700 mb-2">
                <i className="fa-solid fa-folder text-primary mr-1"></i>
                所属分类
              </label>
              <select 
                id="link-category" 
                name="link-category" 
                className={`w-full px-4 py-3 rounded-lg border border-slate-300 ${styles.formInputFocus} transition-all bg-white/80 backdrop-blur-sm`}
                value={linkCategory}
                onChange={(e) => setLinkCategory(e.target.value)}
              >
                <option value="work">工作效率</option>
                <option value="study">学习充电</option>
                <option value="design">设计灵感</option>
                <option value="entertainment">娱乐摸鱼</option>
              </select>
            </div>

            {/* 自定义图标选项 */}
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                <i className="fa-solid fa-palette text-primary mr-1"></i>
                自定义图标
              </label>
              <div className="grid grid-cols-6 gap-3">
                {iconOptions.map((option) => (
                  <button 
                    key={option.class}
                    type="button" 
                    className={`w-12 h-12 rounded-lg border-2 transition-colors flex items-center justify-center ${
                      selectedIcon === option.class 
                        ? 'border-primary bg-primary/10' 
                        : 'border-slate-200 hover:border-primary'
                    }`}
                    onClick={() => handleIconSelect(option.class)}
                  >
                    <i className={`${option.class} text-slate-600`}></i>
                  </button>
                ))}
                <button 
                  type="button" 
                  className="w-12 h-12 rounded-lg border-2 border-dashed border-slate-300 hover:border-primary transition-colors flex items-center justify-center"
                  onClick={handleUploadIcon}
                >
                  <i className="fa-solid fa-upload text-slate-400"></i>
                </button>
              </div>
              <p className="text-xs text-slate-500 mt-2">选择预设图标或上传自定义图标</p>
            </div>

            {/* 表单底部操作按钮 */}
            <div className="pt-4 flex space-x-3">
              <button 
                type="button" 
                onClick={handleClose}
                className="flex-1 px-4 py-3 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium transition-colors"
              >
                <i className="fa-solid fa-times mr-2"></i>
                取消
              </button>
              <button 
                type="submit" 
                disabled={isSaving}
                className="flex-1 px-4 py-3 rounded-lg bg-primary text-white hover:bg-primaryHover font-medium shadow-lg shadow-indigo-500/30 transition-all transform hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <i className="fa-solid fa-check mr-2"></i>
                {isSaving ? '已保存' : '保存更改'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ModalEditLink;

