

export interface Link {
  id: number;
  name: string;
  url: string;
  category: string;
  icon: string;
  isFavorite: boolean;
}

export interface Category {
  name: string;
  icon: string;
}

export type Categories = {
  [key: string]: Category;
};

