

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';
import { Link as LinkType, Category, Categories } from './types';

const HomePage: React.FC = () => {
  const navigate = useNavigate();
  
  // 模拟数据
  const [mockCategories] = useState<Categories>({
    all: { name: '全部推荐', icon: 'fa-layer-group' },
    work: { name: '工作效率', icon: 'fa-briefcase' },
    study: { name: '学习充电', icon: 'fa-graduation-cap' },
    design: { name: '设计灵感', icon: 'fa-pen-nib' },
    entertainment: { name: '娱乐摸鱼', icon: 'fa-gamepad' }
  });

  const [mockLinks, setMockLinks] = useState<LinkType[]>([
    { id: 1, name: 'Dribbble', url: 'https://dribbble.com', category: 'design', icon: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80', isFavorite: true },
    { id: 2, name: 'Instagram', url: 'https://instagram.com', category: 'entertainment', icon: 'https://images.unsplash.com/photo-1611162616305-c69b3fa7fbe0?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80', isFavorite: true },
    { id: 3, name: 'GitHub', url: 'https://github.com', category: 'work', icon: 'https://github.githubassets.com/favicons/favicon.svg', isFavorite: true },
    { id: 4, name: 'Behance', url: 'https://behance.net', category: 'design', icon: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80', isFavorite: true },
    { id: 5, name: 'Google Drive', url: 'https://drive.google.com', category: 'work', icon: 'https://ssl.gstatic.com/images/branding/product/1x/drive_2020q4_48dp.png', isFavorite: false },
    { id: 6, name: 'Figma', url: 'https://figma.com', category: 'design', icon: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80', isFavorite: false },
    { id: 7, name: 'Notion', url: 'https://notion.so', category: 'work', icon: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80', isFavorite: false },
    { id: 8, name: 'AWS Console', url: 'https://aws.amazon.com', category: 'work', icon: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80', isFavorite: false },
    { id: 9, name: 'Pinterest', url: 'https://pinterest.com', category: 'design', icon: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80', isFavorite: false },
    { id: 10, name: 'Unsplash', url: 'https://unsplash.com', category: 'design', icon: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80', isFavorite: false },
    { id: 11, name: 'Google Fonts', url: 'https://fonts.google.com', category: 'design', icon: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80', isFavorite: false },
    { id: 12, name: 'YouTube', url: 'https://youtube.com', category: 'entertainment', icon: 'https://www.youtube.com/s/desktop/4a88d8b9/img/favicon.ico', isFavorite: false },
    { id: 13, name: 'Coursera', url: 'https://coursera.org', category: 'study', icon: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80', isFavorite: false },
    { id: 14, name: 'Medium', url: 'https://medium.com', category: 'study', icon: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80', isFavorite: false },
    { id: 15, name: 'Stack Overflow', url: 'https://stackoverflow.com', category: 'study', icon: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80', isFavorite: false }
  ]);

  // 状态管理
  const [currentCategory, setCurrentCategory] = useState<string>('all');
  const [currentSearch, setCurrentSearch] = useState<string>('');
  const [showAddLinkModal, setShowAddLinkModal] = useState<boolean>(false);
  const [showEditLinkModal, setShowEditLinkModal] = useState<boolean>(false);
  const [showAddCategoryModal, setShowAddCategoryModal] = useState<boolean>(false);
  const [showManageCategoryModal, setShowManageCategoryModal] = useState<boolean>(false);
  const [showConfirmModal, setShowConfirmModal] = useState<boolean>(false);
  const [editingLink, setEditingLink] = useState<LinkType | null>(null);
  const [confirmAction, setConfirmAction] = useState<(() => void) | null>(null);
  const [confirmMessage, setConfirmMessage] = useState<string>('');
  const [currentTime, setCurrentTime] = useState<string>('');
  const [currentDate, setCurrentDate] = useState<string>('');

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '酷站导航 - 您的专属数字空间';
    return () => { document.title = originalTitle; };
  }, []);

  // 更新时间
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const timeString = now.toLocaleTimeString('zh-CN', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: false 
      });
      const dateString = now.toLocaleDateString('zh-CN', { 
        month: 'long', 
        day: 'numeric', 
        weekday: 'short' 
      });
      
      setCurrentTime(timeString);
      setCurrentDate(dateString);
    };

    updateTime();
    const timeInterval = setInterval(updateTime, 60000);

    return () => clearInterval(timeInterval);
  }, []);

  // ESC键关闭弹窗
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setShowAddLinkModal(false);
        setShowEditLinkModal(false);
        setShowAddCategoryModal(false);
        setShowManageCategoryModal(false);
        setShowConfirmModal(false);
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  // 分类切换
  const handleCategorySwitch = (category: string) => {
    setCurrentCategory(category);
    setCurrentSearch('');
  };

  // 搜索过滤
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCurrentSearch(e.target.value.toLowerCase());
  };

  // 过滤链接
  const getFilteredLinks = () => {
    let filteredLinks = mockLinks;

    // 按分类过滤
    if (currentCategory !== 'all') {
      filteredLinks = filteredLinks.filter(link => link.category === currentCategory);
    }

    // 按搜索词过滤
    if (currentSearch) {
      filteredLinks = filteredLinks.filter(link => 
        link.name.toLowerCase().includes(currentSearch) ||
        link.url.toLowerCase().includes(currentSearch)
      );
    }

    return filteredLinks;
  };

  // 获取收藏链接
  const getFavoriteLinks = () => {
    return mockLinks.filter(link => link.isFavorite);
  };

  // 获取当前分类名称
  const getCurrentCategoryName = () => {
    return mockCategories[currentCategory]?.name || '全部推荐';
  };

  // 显示添加链接弹窗
  const handleShowAddLinkModal = () => {
    setShowAddLinkModal(true);
  };

  // 隐藏添加链接弹窗
  const handleHideAddLinkModal = () => {
    setShowAddLinkModal(false);
  };

  // 显示编辑链接弹窗
  const handleShowEditLinkModal = (linkId: number) => {
    const link = mockLinks.find(l => l.id === linkId);
    if (link) {
      setEditingLink(link);
      setShowEditLinkModal(true);
    }
  };

  // 隐藏编辑链接弹窗
  const handleHideEditLinkModal = () => {
    setShowEditLinkModal(false);
    setEditingLink(null);
  };

  // 显示添加分类弹窗
  const handleShowAddCategoryModal = () => {
    setShowAddCategoryModal(true);
  };

  // 隐藏添加分类弹窗
  const handleHideAddCategoryModal = () => {
    setShowAddCategoryModal(false);
  };

  // 显示管理分类弹窗
  const handleShowManageCategoryModal = () => {
    setShowManageCategoryModal(true);
  };

  // 隐藏管理分类弹窗
  const handleHideManageCategoryModal = () => {
    setShowManageCategoryModal(false);
  };

  // 显示确认弹窗
  const handleShowConfirmModal = (message: string, action: () => void) => {
    setConfirmMessage(message);
    setConfirmAction(() => action);
    setShowConfirmModal(true);
  };

  // 隐藏确认弹窗
  const handleHideConfirmModal = () => {
    setShowConfirmModal(false);
    setConfirmAction(null);
    setConfirmMessage('');
  };

  // 执行确认操作
  const handleConfirmAction = () => {
    if (confirmAction) {
      confirmAction();
    }
    handleHideConfirmModal();
  };

  // 添加链接
  const handleAddLink = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const newLink: LinkType = {
      id: Math.max(...mockLinks.map(l => l.id)) + 1,
      name: formData.get('name') as string,
      url: formData.get('url') as string,
      category: formData.get('category') as string,
      icon: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80',
      isFavorite: false
    };

    setMockLinks(prev => [...prev, newLink]);
    handleHideAddLinkModal();
  };

  // 编辑链接
  const handleEditLink = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const linkId = parseInt(formData.get('id') as string);
    
    setMockLinks(prev => prev.map(link => 
      link.id === linkId 
        ? {
            ...link,
            name: formData.get('name') as string,
            url: formData.get('url') as string,
            category: formData.get('category') as string
          }
        : link
    ));

    handleHideEditLinkModal();
  };

  // 删除链接
  const handleDeleteLink = (linkId: number) => {
    setMockLinks(prev => prev.filter(link => link.id !== linkId));
  };

  // 处理弹窗背景点击
  const handleModalBackgroundClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      handleHideAddLinkModal();
      handleHideEditLinkModal();
      handleHideAddCategoryModal();
      handleHideManageCategoryModal();
      handleHideConfirmModal();
    }
  };

  const filteredLinks = getFilteredLinks();
  const favoriteLinks = getFavoriteLinks();
  const nonFavoriteLinks = filteredLinks.filter(link => !link.isFavorite);

  return (
    <div className={styles.pageWrapper}>
      {/* 背景遮罩 */}
      <div className="fixed inset-0 bg-gradient-to-br from-indigo-100/30 to-purple-100/30 pointer-events-none z-0"></div>

      {/* 主应用容器 */}
      <div className={`relative z-10 w-full h-full max-w-[1920px] flex flex-col md:flex-row gap-4 md:gap-6 overflow-hidden rounded-none md:rounded-3xl shadow-2xl ${styles.glassPanel}`}>
        
        {/* 左侧侧边栏 */}
        <aside className="hidden md:flex flex-col w-20 lg:w-64 h-full border-r border-glassBorder bg-white/30 transition-all duration-300">
          {/* Logo 区域 */}
          <div className="h-[80px] flex items-center justify-center lg:justify-start px-0 lg:px-8 border-b border-glassBorder">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-primary to-purple-500 flex items-center justify-center text-white shadow-lg">
              <i className="fa-solid fa-compass text-xl"></i>
            </div>
            <span className="ml-3 text-xl font-bold tracking-tight text-slate-800 hidden lg:block">酷站导航</span>
          </div>

          {/* 分类列表 */}
          <nav className={`flex-1 overflow-y-auto py-6 px-3 space-y-2 ${styles.hideScrollbar}`}>
            {Object.entries(mockCategories).map(([categoryId, category]) => (
              <button
                key={categoryId}
                onClick={() => handleCategorySwitch(categoryId)}
                className={`w-full flex items-center justify-center lg:justify-start px-3 py-3 rounded-xl transition-all group ${
                  currentCategory === categoryId
                    ? styles.navItemActive
                    : `${styles.navItemInactive} text-slate-600`
                }`}
              >
                <i className={`fa-solid ${category.icon} text-lg w-6 text-center ${
                  currentCategory !== categoryId ? 'group-hover:scale-110 transition-transform' : ''
                }`}></i>
                <span className="ml-3 font-medium hidden lg:block">{category.name}</span>
              </button>
            ))}
            
            <div className="my-4 border-t border-glassBorder w-full"></div>

            <button 
              onClick={handleShowAddCategoryModal}
              className="w-full flex items-center justify-center lg:justify-start px-3 py-3 rounded-xl text-slate-500 hover:bg-slate-200/50 transition-all"
            >
              <i className="fa-solid fa-plus text-lg w-6 text-center"></i>
              <span className="ml-3 font-medium text-sm hidden lg:block">添加分类</span>
            </button>

            <button 
              onClick={handleShowManageCategoryModal}
              className="w-full flex items-center justify-center lg:justify-start px-3 py-3 rounded-xl text-slate-500 hover:bg-slate-200/50 transition-all"
            >
              <i className="fa-solid fa-gear text-lg w-6 text-center"></i>
              <span className="ml-3 font-medium text-sm hidden lg:block">管理分类</span>
            </button>
          </nav>

          {/* 底部用户信息 */}
          <div className="p-4 border-t border-glassBorder">
            <Link 
              to="/settings"
              className="flex items-center justify-center lg:justify-start p-2 rounded-xl hover:bg-white/40 transition-colors cursor-pointer w-full"
            >
              <img 
                src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" 
                alt="用户头像" 
                className="w-10 h-10 rounded-full border-2 border-white shadow-sm object-cover"
              />
              <div className="ml-3 hidden lg:block overflow-hidden">
                <p className="text-sm font-bold text-slate-800 truncate">Alex Designer</p>
                <p className="text-xs text-slate-500 truncate">点击进入设置</p>
              </div>
            </Link>
          </div>
        </aside>

        {/* 右侧主内容区 */}
        <main className="flex-1 flex flex-col h-full overflow-hidden relative">
          
          {/* 顶部导航栏 */}
          <header className="h-[80px] flex items-center justify-between px-6 md:px-10 py-4 shrink-0 z-20">
            {/* 移动端汉堡菜单 */}
            <button className="md:hidden p-2 text-slate-600 hover:text-primary">
              <i className="fa-solid fa-bars text-2xl"></i>
            </button>

            {/* 移动端 Logo */}
            <span className="md:hidden text-lg font-bold text-slate-800">酷站导航</span>

            {/* 搜索框 */}
            <div className={`hidden md:flex flex-1 max-w-2xl mx-auto relative group ${styles.searchFocus} rounded-full transition-all duration-300 bg-white/60 backdrop-blur-md border border-white/50`}>
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <i className="fa-solid fa-search text-slate-400 group-focus-within:text-primary transition-colors"></i>
              </div>
              <input 
                type="text" 
                value={currentSearch}
                onChange={handleSearchChange}
                className="block w-full pl-12 pr-4 py-3 bg-transparent border-none rounded-full text-slate-800 placeholder-slate-400 focus:ring-0 sm:text-sm" 
                placeholder="搜索书签、Google 或输入网址..."
              />
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                <span className="text-xs text-slate-400 border border-slate-300 rounded px-1.5 py-0.5">⌘K</span>
              </div>
            </div>

            {/* 右侧操作区 */}
            <div className="flex items-center space-x-4 ml-4">
              {/* 时间显示 */}
              <div className="hidden xl:flex flex-col items-end mr-4 text-right">
                <span className="text-lg font-bold text-slate-700 leading-none">{currentTime}</span>
                <span className="text-xs text-slate-500">{currentDate}</span>
              </div>

              {/* 添加按钮 */}
              <button 
                onClick={handleShowAddLinkModal}
                className="flex items-center justify-center px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-full shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-0.5"
              >
                <i className="fa-solid fa-plus mr-2"></i>
                <span className="text-sm font-medium">添加</span>
              </button>
              
              {/* 移动端设置入口 */}
              <Link to="/settings" className="md:hidden p-2 text-slate-600">
                <img 
                  src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" 
                  alt="用户头像" 
                  className="w-8 h-8 rounded-full border border-white shadow-sm"
                />
              </Link>
            </div>
          </header>

          {/* 内容滚动区 */}
          <div className={`flex-1 overflow-y-auto p-6 md:p-10 ${styles.hideScrollbar}`}>
            
            {/* 面包屑导航 */}
            <nav className="mb-6">
              <ol className="flex items-center space-x-2 text-sm text-slate-500">
                <li className={styles.breadcrumbItem}>
                  <span className="text-slate-700 font-medium">酷站导航</span>
                </li>
                <li className={styles.breadcrumbItem}>
                  <span className="text-slate-700 font-medium">{getCurrentCategoryName()}</span>
                </li>
              </ol>
            </nav>

            {/* 欢迎语 */}
            <div className="mb-8 animate-fade-in-up">
              <h1 className="text-2xl md:text-3xl font-bold text-slate-800 mb-2">早安，Alex ☀️</h1>
              <p className="text-slate-500">准备好开始高效的一天了吗？</p>
            </div>

            {/* 常用/置顶区域 */}
            {favoriteLinks.length > 0 && (
              <section className="mb-10">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold text-slate-700 flex items-center">
                    <i className="fa-solid fa-star text-yellow-400 mr-2"></i> 常用访问
                  </h2>
                  <button className="text-xs text-slate-400 hover:text-primary transition-colors">编辑</button>
                </div>
                
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">
                  {favoriteLinks.map(link => (
                    <a 
                      key={link.id}
                      href={link.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className={`${styles.glassCard} group relative flex flex-col items-center justify-center p-6 rounded-2xl h-32 md:h-40 cursor-pointer`}
                    >
                      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button 
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            handleShowEditLinkModal(link.id);
                          }}
                          className="text-slate-400 hover:text-slate-600 p-1"
                        >
                          <i className="fa-solid fa-ellipsis-vertical"></i>
                        </button>
                      </div>
                      <div className="w-12 h-12 md:w-14 md:h-14 rounded-2xl bg-white shadow-md flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300">
                        <img src={link.icon} alt={`${link.name}图标`} className="w-8 h-8 object-contain" />
                      </div>
                      <span className="text-sm font-medium text-slate-700 group-hover:text-primary transition-colors">{link.name}</span>
                    </a>
                  ))}
                </div>
              </section>
            )}

            {/* 当前分类内容区域 */}
            <section className="mb-10">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-slate-700">{getCurrentCategoryName()}</h2>
                <div className="flex items-center space-x-2">
                  <button className="text-xs text-slate-400 hover:text-primary transition-colors">
                    <i className="fa-solid fa-sort mr-1"></i>排序
                  </button>
                </div>
              </div>
              
              {nonFavoriteLinks.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                  {nonFavoriteLinks.map(link => (
                    <a 
                      key={link.id}
                      href={link.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className={`${styles.glassCard} flex items-center p-4 rounded-xl hover:bg-white transition-colors group`}
                    >
                      <div className="w-10 h-10 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center shrink-0">
                        <img src={link.icon} alt={`${link.name}图标`} className="w-6 h-6 object-contain" />
                      </div>
                      <div className="ml-3 overflow-hidden flex-1">
                        <h3 className="text-sm font-semibold text-slate-800 truncate group-hover:text-primary">{link.name}</h3>
                        <p className="text-xs text-slate-500 truncate">{link.url}</p>
                      </div>
                      <div className="ml-2 opacity-0 group-hover:opacity-100 transition-opacity flex space-x-1">
                        <button 
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            handleShowEditLinkModal(link.id);
                          }}
                          className="text-slate-400 hover:text-primary p-1"
                        >
                          <i className="fa-solid fa-edit text-xs"></i>
                        </button>
                        <button 
                          onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            handleShowConfirmModal(`确定要删除"${link.name}"吗？`, () => handleDeleteLink(link.id));
                          }}
                          className="text-slate-400 hover:text-red-500 p-1"
                        >
                          <i className="fa-solid fa-trash text-xs"></i>
                        </button>
                      </div>
                    </a>
                  ))}
                </div>
              ) : (
                /* 无数据提示 */
                <div className="text-center py-16">
                  <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-slate-100 flex items-center justify-center">
                    <i className="fa-solid fa-link text-2xl text-slate-400"></i>
                  </div>
                  <h3 className="text-lg font-medium text-slate-700 mb-2">暂无网站链接</h3>
                  <p className="text-slate-500 mb-6">开始添加您的第一个网站链接吧</p>
                  <button 
                    onClick={handleShowAddLinkModal}
                    className="px-6 py-2 bg-primary text-white rounded-lg hover:bg-primaryHover transition-colors"
                  >
                    <i className="fa-solid fa-plus mr-2"></i>添加链接
                  </button>
                </div>
              )}
            </section>

            {/* 底部留白 */}
            <div className="h-10"></div>
          </div>
        </main>
      </div>

      {/* 添加链接弹窗 */}
      {showAddLinkModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" onClick={handleModalBackgroundClick}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm"></div>
          <div className={`relative bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 m-4 ${styles.modalEnter} ${styles.modalEnterActive}`}>
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-slate-800">添加新导航</h3>
              <button onClick={handleHideAddLinkModal} className="text-slate-400 hover:text-slate-600">
                <i className="fa-solid fa-xmark text-xl"></i>
              </button>
            </div>
            
            <form onSubmit={handleAddLink} className="space-y-4">
              <div>
                <label htmlFor="link-url" className="block text-sm font-medium text-slate-700 mb-1">网址 URL *</label>
                <input 
                  type="url" 
                  id="link-url" 
                  name="url" 
                  placeholder="https://example.com" 
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-all" 
                  required 
                />
              </div>
              <div>
                <label htmlFor="link-name" className="block text-sm font-medium text-slate-700 mb-1">名称 *</label>
                <input 
                  type="text" 
                  id="link-name" 
                  name="name" 
                  placeholder="网站名称" 
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-all" 
                  required 
                />
              </div>
              <div>
                <label htmlFor="link-category" className="block text-sm font-medium text-slate-700 mb-1">分类</label>
                <select 
                  id="link-category" 
                  name="category" 
                  defaultValue={currentCategory}
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-all bg-white"
                >
                  {Object.entries(mockCategories).map(([id, category]) => (
                    <option key={id} value={id}>{category.name}</option>
                  ))}
                </select>
              </div>
              
              <div className="pt-4 flex space-x-3">
                <button 
                  type="button" 
                  onClick={handleHideAddLinkModal}
                  className="flex-1 px-4 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium transition-colors"
                >
                  取消
                </button>
                <button 
                  type="submit" 
                  className="flex-1 px-4 py-2 rounded-lg bg-primary text-white hover:bg-primaryHover font-medium shadow-lg shadow-indigo-500/30 transition-all"
                >
                  保存
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 编辑链接弹窗 */}
      {showEditLinkModal && editingLink && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" onClick={handleModalBackgroundClick}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm"></div>
          <div className={`relative bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 m-4 ${styles.modalEnter} ${styles.modalEnterActive}`}>
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-slate-800">编辑导航</h3>
              <button onClick={handleHideEditLinkModal} className="text-slate-400 hover:text-slate-600">
                <i className="fa-solid fa-xmark text-xl"></i>
              </button>
            </div>
            
            <form onSubmit={handleEditLink} className="space-y-4">
              <input type="hidden" name="id" value={editingLink.id} />
              <div>
                <label htmlFor="edit-link-url" className="block text-sm font-medium text-slate-700 mb-1">网址 URL *</label>
                <input 
                  type="url" 
                  id="edit-link-url" 
                  name="url" 
                  value={editingLink.url}
                  placeholder="https://example.com" 
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-all" 
                  required 
                />
              </div>
              <div>
                <label htmlFor="edit-link-name" className="block text-sm font-medium text-slate-700 mb-1">名称 *</label>
                <input 
                  type="text" 
                  id="edit-link-name" 
                  name="name" 
                  value={editingLink.name}
                  placeholder="网站名称" 
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-all" 
                  required 
                />
              </div>
              <div>
                <label htmlFor="edit-link-category" className="block text-sm font-medium text-slate-700 mb-1">分类</label>
                <select 
                  id="edit-link-category" 
                  name="category" 
                  value={editingLink.category}
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-all bg-white"
                >
                  {Object.entries(mockCategories).map(([id, category]) => (
                    <option key={id} value={id}>{category.name}</option>
                  ))}
                </select>
              </div>
              
              <div className="pt-4 flex space-x-3">
                <button 
                  type="button" 
                  onClick={handleHideEditLinkModal}
                  className="flex-1 px-4 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium transition-colors"
                >
                  取消
                </button>
                <button 
                  type="submit" 
                  className="flex-1 px-4 py-2 rounded-lg bg-primary text-white hover:bg-primaryHover font-medium shadow-lg shadow-indigo-500/30 transition-all"
                >
                  保存
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 添加分类弹窗 */}
      {showAddCategoryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" onClick={handleModalBackgroundClick}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm"></div>
          <div className={`relative bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 m-4 ${styles.modalEnter} ${styles.modalEnterActive}`}>
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-slate-800">添加分类</h3>
              <button onClick={handleHideAddCategoryModal} className="text-slate-400 hover:text-slate-600">
                <i className="fa-solid fa-xmark text-xl"></i>
              </button>
            </div>
            
            <form className="space-y-4">
              <div>
                <label htmlFor="category-name" className="block text-sm font-medium text-slate-700 mb-1">分类名称 *</label>
                <input 
                  type="text" 
                  id="category-name" 
                  name="name" 
                  placeholder="分类名称" 
                  className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-primary focus:border-primary outline-none transition-all" 
                  required 
                />
              </div>
              
              <div className="pt-4 flex space-x-3">
                <button 
                  type="button" 
                  onClick={handleHideAddCategoryModal}
                  className="flex-1 px-4 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium transition-colors"
                >
                  取消
                </button>
                <button 
                  type="submit" 
                  className="flex-1 px-4 py-2 rounded-lg bg-primary text-white hover:bg-primaryHover font-medium shadow-lg shadow-indigo-500/30 transition-all"
                >
                  保存
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 管理分类弹窗 */}
      {showManageCategoryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" onClick={handleModalBackgroundClick}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm"></div>
          <div className={`relative bg-white rounded-2xl shadow-2xl w-full max-w-2xl p-6 m-4 ${styles.modalEnter} ${styles.modalEnterActive} max-h-[80vh] overflow-y-auto`}>
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-slate-800">管理分类</h3>
              <button onClick={handleHideManageCategoryModal} className="text-slate-400 hover:text-slate-600">
                <i className="fa-solid fa-xmark text-xl"></i>
              </button>
            </div>
            
            <div className="space-y-3">
              {Object.entries(mockCategories).map(([categoryId, category]) => (
                <div key={categoryId} className="flex items-center justify-between p-4 rounded-lg bg-slate-50 hover:bg-slate-100 transition-colors">
                  <div className="flex items-center">
                    <i className={`fa-solid ${category.icon} text-lg text-slate-600 mr-3`}></i>
                    <span className="font-medium text-slate-800">{category.name}</span>
                  </div>
                  <div className="flex space-x-2">
                    <button 
                      className="px-3 py-1 text-xs text-slate-600 hover:text-primary border border-slate-300 rounded-lg hover:border-primary transition-colors"
                    >
                      编辑
                    </button>
                    <button 
                      onClick={() => handleShowConfirmModal(`确定要删除分类"${category.name}"吗？分类下的所有链接也将被删除。`, () => {
                        // 删除分类逻辑
                        console.log('删除分类:', categoryId);
                      })}
                      className="px-3 py-1 text-xs text-red-600 hover:text-red-700 border border-red-300 rounded-lg hover:border-red-400 transition-colors"
                    >
                      删除
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 确认弹窗 */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" onClick={handleModalBackgroundClick}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm"></div>
          <div className={`relative bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 m-4 ${styles.modalEnter} ${styles.modalEnterActive}`}>
            <div className="text-center mb-6">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-red-100 flex items-center justify-center">
                <i className="fa-solid fa-exclamation-triangle text-2xl text-red-600"></i>
              </div>
              <h3 className="text-lg font-bold text-slate-800 mb-2">确认删除</h3>
              <p className="text-slate-600">{confirmMessage}</p>
            </div>
            
            <div className="flex space-x-3">
              <button 
                onClick={handleHideConfirmModal}
                className="flex-1 px-4 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium transition-colors"
              >
                取消
              </button>
              <button 
                onClick={handleConfirmAction}
                className="flex-1 px-4 py-2 rounded-lg bg-red-500 text-white hover:bg-red-600 font-medium transition-colors"
              >
                确认
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default HomePage;

