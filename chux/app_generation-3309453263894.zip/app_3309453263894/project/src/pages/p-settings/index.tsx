

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

type SettingType = 'account' | 'appearance' | 'data' | 'about';
type ThemeType = 'light' | 'dark' | 'auto';
type LayoutType = 'grid' | 'list';

interface UserProfile {
  username: string;
  email: string;
  avatar: string;
}

interface SettingsData {
  theme: ThemeType;
  background: string;
  layout: LayoutType;
  searchEngine: string;
  username: string;
}

const SettingsPage: React.FC = () => {
  const navigate = useNavigate();
  
  // 状态管理
  const [currentSetting, setCurrentSetting] = useState<SettingType>('account');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState('');
  const [currentDate, setCurrentDate] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  // 表单数据
  const [userProfile, setUserProfile] = useState<UserProfile>({
    username: 'Alex Designer',
    email: 'alex@example.com',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80'
  });
  
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  
  const [settings, setSettings] = useState<SettingsData>({
    theme: 'light',
    background: 'https://images.unsplash.com/photo-1477346611705-65d1883cee1e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80',
    layout: 'grid',
    searchEngine: 'baidu'
  });

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '设置 - 极简导航';
    return () => { document.title = originalTitle; };
  }, []);

  // 更新时间显示
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const timeString = now.toLocaleTimeString('zh-CN', { 
        hour12: false, 
        hour: '2-digit', 
        minute: '2-digit' 
      });
      const dateString = now.toLocaleDateString('zh-CN', { 
        month: 'long', 
        day: 'numeric', 
        weekday: 'short' 
      });
      
      setCurrentTime(timeString);
      setCurrentDate(dateString);
    };
    
    updateTime();
    const timeInterval = setInterval(updateTime, 60000);
    
    return () => clearInterval(timeInterval);
  }, []);

  // 处理设置菜单切换
  const handleSettingChange = (settingType: SettingType) => {
    setCurrentSetting(settingType);
    setIsMobileMenuOpen(false);
  };

  // 处理移动端菜单切换
  const handleMobileMenuToggle = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  // 处理主题切换
  const handleThemeChange = (theme: ThemeType) => {
    setSettings(prev => ({ ...prev, theme }));
  };

  // 处理背景选择
  const handleBackgroundChange = (background: string) => {
    setSettings(prev => ({ ...prev, background }));
  };

  // 处理布局选择
  const handleLayoutChange = (layout: LayoutType) => {
    setSettings(prev => ({ ...prev, layout }));
  };

  // 处理搜索引擎选择
  const handleSearchEngineChange = (searchEngine: string) => {
    setSettings(prev => ({ ...prev, searchEngine }));
  };

  // 处理用户名更新
  const handleUsernameChange = (username: string) => {
    setUserProfile(prev => ({ ...prev, username }));
    setSettings(prev => ({ ...prev, username }));
  };

  // 处理密码表单更新
  const handlePasswordFormChange = (field: string, value: string) => {
    setPasswordForm(prev => ({ ...prev, [field]: value }));
  };

  // 处理头像上传
  const handleAvatarUpload = () => {
    console.log('需要调用第三方接口实现头像上传功能');
    // 注释：此功能需要文件上传API，在原型阶段仅做UI展示
  };

  // 处理文件导入
  const handleFileImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files.length > 0) {
      console.log('需要调用第三方接口实现文件导入功能');
      // 注释：此功能需要文件读取API，在原型阶段仅做UI展示
    }
  };

  // 处理数据导入导出
  const handleImportBookmarks = () => {
    console.log('需要调用第三方接口实现浏览器书签导入功能');
    // 注释：此功能需要浏览器书签API，在原型阶段仅做UI展示
  };

  const handleExportAll = () => {
    console.log('需要调用第三方接口实现数据导出功能');
    // 注释：此功能需要文件下载API，在原型阶段仅做UI展示
  };

  const handleExportBookmarks = () => {
    console.log('需要调用第三方接口实现书签导出功能');
    // 注释：此功能需要文件下载API，在原型阶段仅做UI展示
  };

  // 处理表单提交
  const handleProfileSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    console.log('个人信息已更新');
  };

  const handlePasswordSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    console.log('密码已更新');
  };

  // 处理保存设置
  const handleSaveSettings = async () => {
    setIsLoading(true);
    
    const allSettings = {
      ...settings,
      username: userProfile.username
    };
    
    console.log('设置已保存:', allSettings);
    
    // 模拟保存延迟
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setIsLoading(false);
  };

  // 处理取消
  const handleCancel = () => {
    if (confirm('确定要取消所有未保存的更改吗？')) {
      window.location.reload();
    }
  };

  // 处理返回首页
  const handleBackToHome = () => {
    navigate(-1);
  };

  // 处理搜索
  const handleSearch = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter') {
      const target = event.target as HTMLInputElement;
      const query = target.value.trim();
      if (query) {
        console.log('搜索:', query);
        // 这里可以实现搜索功能
      }
    }
  };

  // 背景选项数据
  const backgroundOptions = [
    {
      url: 'https://images.unsplash.com/photo-1477346611705-65d1883cee1e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80',
      thumbnail: 'https://images.unsplash.com/photo-1477346611705-65d1883cee1e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80',
      alt: '默认背景',
      category: '自然风景'
    },
    {
      url: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80',
      thumbnail: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80',
      alt: '山脉背景',
      category: '自然风景'
    },
    {
      url: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80',
      thumbnail: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80',
      alt: '森林背景',
      category: '自然风景'
    },
    {
      url: 'custom',
      thumbnail: '',
      alt: '自定义背景',
      category: '自定义'
    }
  ];

  return (
    <div className={styles.pageWrapper}>
      {/* 背景遮罩，用于提升文字可读性 */}
      <div className="fixed inset-0 bg-gradient-to-br from-indigo-100/30 to-purple-100/30 pointer-events-none z-0"></div>

      {/* 主应用容器 */}
      <div className={`relative z-10 w-full h-full max-w-[1920px] flex flex-col md:flex-row gap-4 md:gap-6 overflow-hidden rounded-none md:rounded-3xl shadow-2xl ${styles.glassPanel}`}>
        
        {/* 左侧侧边栏 (设置菜单) */}
        <aside className={`${isMobileMenuOpen ? 'fixed inset-0 z-50' : 'hidden'} md:flex flex-col w-20 lg:w-64 h-full border-r border-glassBorder bg-white/30 transition-all duration-300`}>
          {/* Logo 区域 */}
          <div className="h-[80px] flex items-center justify-center lg:justify-start px-0 lg:px-8 border-b border-glassBorder">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-primary to-purple-500 flex items-center justify-center text-white shadow-lg">
              <i className="fa-solid fa-cog text-xl"></i>
            </div>
            <span className="ml-3 text-xl font-bold tracking-tight text-slate-800 hidden lg:block">设置中心</span>
          </div>

          {/* 设置菜单列表 */}
          <nav className={`flex-1 overflow-y-auto py-6 px-3 space-y-2 ${styles.hideScrollbar}`}>
            {/* 账户设置 */}
            <button 
              onClick={() => handleSettingChange('account')}
              className={`w-full flex items-center justify-center lg:justify-start px-3 py-3 rounded-xl transition-all group ${
                currentSetting === 'account' ? styles.navItemActive : `${styles.navItemInactive} text-slate-600`
              }`}
            >
              <i className="fa-solid fa-user text-lg w-6 text-center"></i>
              <span className="ml-3 font-medium hidden lg:block">账户设置</span>
            </button>

            {/* 外观设置 */}
            <button 
              onClick={() => handleSettingChange('appearance')}
              className={`w-full flex items-center justify-center lg:justify-start px-3 py-3 rounded-xl transition-all group ${
                currentSetting === 'appearance' ? styles.navItemActive : `${styles.navItemInactive} text-slate-600`
              }`}
            >
              <i className="fa-solid fa-palette text-lg w-6 text-center group-hover:scale-110 transition-transform"></i>
              <span className="ml-3 font-medium hidden lg:block">外观设置</span>
            </button>

            {/* 数据管理 */}
            <button 
              onClick={() => handleSettingChange('data')}
              className={`w-full flex items-center justify-center lg:justify-start px-3 py-3 rounded-xl transition-all group ${
                currentSetting === 'data' ? styles.navItemActive : `${styles.navItemInactive} text-slate-600`
              }`}
            >
              <i className="fa-solid fa-database text-lg w-6 text-center group-hover:scale-110 transition-transform"></i>
              <span className="ml-3 font-medium hidden lg:block">数据管理</span>
            </button>

            {/* 关于 */}
            <button 
              onClick={() => handleSettingChange('about')}
              className={`w-full flex items-center justify-center lg:justify-start px-3 py-3 rounded-xl transition-all group ${
                currentSetting === 'about' ? styles.navItemActive : `${styles.navItemInactive} text-slate-600`
              }`}
            >
              <i className="fa-solid fa-info-circle text-lg w-6 text-center group-hover:scale-110 transition-transform"></i>
              <span className="ml-3 font-medium hidden lg:block">关于</span>
            </button>
          </nav>

          {/* 底部返回 */}
          <div className="p-4 border-t border-glassBorder">
            <button 
              onClick={handleBackToHome}
              className="w-full flex items-center justify-center lg:justify-start p-2 rounded-xl hover:bg-white/40 transition-colors"
            >
              <i className="fa-solid fa-arrow-left text-lg w-6 text-center"></i>
              <span className="ml-3 font-medium text-sm hidden lg:block">返回首页</span>
            </button>
          </div>
        </aside>

        {/* 右侧主内容区 */}
        <main className="flex-1 flex flex-col h-full overflow-hidden relative">
          
          {/* 顶部导航栏 */}
          <header className="h-[80px] flex items-center justify-between px-6 md:px-10 py-4 shrink-0 z-20">
            {/* 移动端汉堡菜单 */}
            <button 
              onClick={handleMobileMenuToggle}
              className="md:hidden p-2 text-slate-600 hover:text-primary"
            >
              <i className="fa-solid fa-bars text-2xl"></i>
            </button>

            {/* 移动端标题 */}
            <span className="md:hidden text-lg font-bold text-slate-800">设置中心</span>

            {/* 搜索框 (桌面端) */}
            <div className={`hidden md:flex flex-1 max-w-2xl mx-auto relative group ${styles.searchFocus} rounded-full transition-all duration-300 bg-white/60 backdrop-blur-md border border-white/50`}>
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <i className="fa-solid fa-search text-slate-400 group-focus-within:text-primary transition-colors"></i>
              </div>
              <input 
                type="text" 
                onKeyPress={handleSearch}
                className="block w-full pl-12 pr-4 py-3 bg-transparent border-none rounded-full text-slate-800 placeholder-slate-400 focus:ring-0 sm:text-sm" 
                placeholder="搜索书签、Google 或输入网址..."
              />
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                <span className="text-xs text-slate-400 border border-slate-300 rounded px-1.5 py-0.5">⌘K</span>
              </div>
            </div>

            {/* 右侧操作区 */}
            <div className="flex items-center space-x-4 ml-4">
              {/* 时间显示 */}
              <div className="hidden xl:flex flex-col items-end mr-4 text-right">
                <span className="text-lg font-bold text-slate-700 leading-none">{currentTime}</span>
                <span className="text-xs text-slate-500">{currentDate}</span>
              </div>
              
              {/* 移动端返回 */}
              <button 
                onClick={handleBackToHome}
                className="md:hidden p-2 text-slate-600"
              >
                <i className="fa-solid fa-arrow-left text-xl"></i>
              </button>
            </div>
          </header>

          {/* 内容滚动区 */}
          <div className={`flex-1 overflow-y-auto p-6 md:p-10 ${styles.hideScrollbar}`}>
            
            {/* 账户设置 */}
            {currentSetting === 'account' && (
              <div className={styles.settingSection}>
                <div className="mb-8">
                  <h1 className="text-2xl md:text-3xl font-bold text-slate-800 mb-2">账户设置</h1>
                  <p className="text-slate-500">管理您的个人信息和账户安全</p>
                </div>

                <div className="space-y-6">
                  {/* 头像设置 */}
                  <div className={`${styles.glassCard} rounded-2xl p-6`}>
                    <h3 className="text-lg font-semibold text-slate-800 mb-4">头像设置</h3>
                    <div className="flex items-center space-x-6">
                      <div className="relative">
                        <img 
                          src={userProfile.avatar}
                          alt="当前头像" 
                          data-category="人物"
                          className="w-20 h-20 rounded-full border-4 border-white shadow-lg object-cover"
                        />
                        <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-secondary rounded-full flex items-center justify-center text-white text-xs shadow-md">
                          <i className="fa-solid fa-check"></i>
                        </div>
                      </div>
                      <div className="flex-1">
                        <button 
                          onClick={handleAvatarUpload}
                          className={`${styles.avatarUploadArea} rounded-xl p-4 text-center cursor-pointer w-full`}
                        >
                          <i className="fa-solid fa-camera text-2xl text-slate-400 mb-2 block"></i>
                          <p className="text-sm text-slate-600">点击上传新头像</p>
                          <p className="text-xs text-slate-400 mt-1">支持 JPG、PNG 格式，最大 2MB</p>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* 个人信息 */}
                  <div className={`${styles.glassCard} rounded-2xl p-6`}>
                    <h3 className="text-lg font-semibold text-slate-800 mb-4">个人信息</h3>
                    <form onSubmit={handleProfileSubmit} className="space-y-4">
                      <div>
                        <label htmlFor="username" className="block text-sm font-medium text-slate-700 mb-2">用户名</label>
                        <input 
                          type="text" 
                          id="username" 
                          name="username" 
                          value={userProfile.username}
                          onChange={(e) => handleUsernameChange(e.target.value)}
                          className={`w-full px-4 py-3 rounded-lg border border-slate-300 ${styles.formInputFocus} bg-white/80 backdrop-blur-sm`}
                          placeholder="请输入用户名"
                        />
                      </div>
                      <div>
                        <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-2">邮箱地址</label>
                        <input 
                          type="email" 
                          id="email" 
                          name="email" 
                          value={userProfile.email}
                          className={`w-full px-4 py-3 rounded-lg border border-slate-300 ${styles.formInputFocus} bg-white/80 backdrop-blur-sm`}
                          placeholder="请输入邮箱地址"
                          readOnly
                        />
                        <p className="text-xs text-slate-400 mt-1">邮箱地址不可修改</p>
                      </div>
                    </form>
                  </div>

                  {/* 密码修改 */}
                  <div className={`${styles.glassCard} rounded-2xl p-6`}>
                    <h3 className="text-lg font-semibold text-slate-800 mb-4">密码修改</h3>
                    <form onSubmit={handlePasswordSubmit} className="space-y-4">
                      <div>
                        <label htmlFor="current-password" className="block text-sm font-medium text-slate-700 mb-2">当前密码</label>
                        <input 
                          type="password" 
                          id="current-password" 
                          name="current-password" 
                          value={passwordForm.currentPassword}
                          onChange={(e) => handlePasswordFormChange('currentPassword', e.target.value)}
                          className={`w-full px-4 py-3 rounded-lg border border-slate-300 ${styles.formInputFocus} bg-white/80 backdrop-blur-sm`}
                          placeholder="请输入当前密码"
                        />
                      </div>
                      <div>
                        <label htmlFor="new-password" className="block text-sm font-medium text-slate-700 mb-2">新密码</label>
                        <input 
                          type="password" 
                          id="new-password" 
                          name="new-password" 
                          value={passwordForm.newPassword}
                          onChange={(e) => handlePasswordFormChange('newPassword', e.target.value)}
                          className={`w-full px-4 py-3 rounded-lg border border-slate-300 ${styles.formInputFocus} bg-white/80 backdrop-blur-sm`}
                          placeholder="请输入新密码"
                        />
                      </div>
                      <div>
                        <label htmlFor="confirm-password" className="block text-sm font-medium text-slate-700 mb-2">确认新密码</label>
                        <input 
                          type="password" 
                          id="confirm-password" 
                          name="confirm-password" 
                          value={passwordForm.confirmPassword}
                          onChange={(e) => handlePasswordFormChange('confirmPassword', e.target.value)}
                          className={`w-full px-4 py-3 rounded-lg border border-slate-300 ${styles.formInputFocus} bg-white/80 backdrop-blur-sm`}
                          placeholder="请再次输入新密码"
                        />
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            )}

            {/* 外观设置 */}
            {currentSetting === 'appearance' && (
              <div className={styles.settingSection}>
                <div className="mb-8">
                  <h1 className="text-2xl md:text-3xl font-bold text-slate-800 mb-2">外观设置</h1>
                  <p className="text-slate-500">个性化您的导航页面</p>
                </div>

                <div className="space-y-6">
                  {/* 主题切换 */}
                  <div className={`${styles.glassCard} rounded-2xl p-6`}>
                    <h3 className="text-lg font-semibold text-slate-800 mb-4">主题模式</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <button 
                        onClick={() => handleThemeChange('light')}
                        className={`${styles.settingOption} ${settings.theme === 'light' ? styles.settingOptionSelected : ''} p-4 rounded-xl text-center transition-all`}
                      >
                        <i className="fa-solid fa-sun text-2xl text-yellow-500 mb-2 block"></i>
                        <p className="font-medium">亮色模式</p>
                        <p className="text-xs text-slate-500">清爽明亮的界面</p>
                      </button>
                      <button 
                        onClick={() => handleThemeChange('dark')}
                        className={`${styles.settingOption} ${settings.theme === 'dark' ? styles.settingOptionSelected : ''} p-4 rounded-xl text-center transition-all`}
                      >
                        <i className="fa-solid fa-moon text-2xl text-slate-600 mb-2 block"></i>
                        <p className="font-medium">暗色模式</p>
                        <p className="text-xs text-slate-500">护眼深色主题</p>
                      </button>
                      <button 
                        onClick={() => handleThemeChange('auto')}
                        className={`${styles.settingOption} ${settings.theme === 'auto' ? styles.settingOptionSelected : ''} p-4 rounded-xl text-center transition-all`}
                      >
                        <i className="fa-solid fa-circle-half-stroke text-2xl text-slate-600 mb-2 block"></i>
                        <p className="font-medium">跟随系统</p>
                        <p className="text-xs text-slate-500">自动切换主题</p>
                      </button>
                    </div>
                  </div>

                  {/* 背景设置 */}
                  <div className={`${styles.glassCard} rounded-2xl p-6`}>
                    <h3 className="text-lg font-semibold text-slate-800 mb-4">背景设置</h3>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {backgroundOptions.map((option, index) => (
                          <button 
                            key={index}
                            onClick={() => handleBackgroundChange(option.url)}
                            className={`aspect-square rounded-xl overflow-hidden border-2 transition-all ${
                              settings.background === option.url ? `border-primary ${styles.bgOptionSelected}` : 'border-slate-300'
                            }`}
                          >
                            {option.url === 'custom' ? (
                              <div className="w-full h-full flex items-center justify-center bg-slate-100">
                                <i className="fa-solid fa-upload text-2xl text-slate-400"></i>
                              </div>
                            ) : (
                              <img 
                                src={option.thumbnail}
                                alt={option.alt}
                                data-category={option.category}
                                className="w-full h-full object-cover"
                              />
                            )}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* 布局设置 */}
                  <div className={`${styles.glassCard} rounded-2xl p-6`}>
                    <h3 className="text-lg font-semibold text-slate-800 mb-4">布局设置</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">网站链接布局</label>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <button 
                            onClick={() => handleLayoutChange('grid')}
                            className={`${styles.settingOption} ${settings.layout === 'grid' ? styles.settingOptionSelected : ''} p-4 rounded-xl text-center transition-all`}
                          >
                            <i className="fa-solid fa-th text-2xl text-slate-600 mb-2 block"></i>
                            <p className="font-medium">宫格布局</p>
                            <p className="text-xs text-slate-500">整齐的网格排列</p>
                          </button>
                          <button 
                            onClick={() => handleLayoutChange('list')}
                            className={`${styles.settingOption} ${settings.layout === 'list' ? styles.settingOptionSelected : ''} p-4 rounded-xl text-center transition-all`}
                          >
                            <i className="fa-solid fa-list text-2xl text-slate-600 mb-2 block"></i>
                            <p className="font-medium">列表布局</p>
                            <p className="text-xs text-slate-500">简洁的列表显示</p>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 搜索设置 */}
                  <div className={`${styles.glassCard} rounded-2xl p-6`}>
                    <h3 className="text-lg font-semibold text-slate-800 mb-4">搜索设置</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">默认搜索引擎</label>
                        <select 
                          value={settings.searchEngine}
                          onChange={(e) => handleSearchEngineChange(e.target.value)}
                          className={`w-full px-4 py-3 rounded-lg border border-slate-300 ${styles.formInputFocus} bg-white/80 backdrop-blur-sm`}
                        >
                          <option value="google">Google</option>
                          <option value="baidu">百度</option>
                          <option value="bing">Bing</option>
                          <option value="yahoo">Yahoo</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 数据管理 */}
            {currentSetting === 'data' && (
              <div className={styles.settingSection}>
                <div className="mb-8">
                  <h1 className="text-2xl md:text-3xl font-bold text-slate-800 mb-2">数据管理</h1>
                  <p className="text-slate-500">管理您的书签数据</p>
                </div>

                <div className="space-y-6">
                  {/* 数据导入 */}
                  <div className={`${styles.glassCard} rounded-2xl p-6`}>
                    <h3 className="text-lg font-semibold text-slate-800 mb-4">数据导入</h3>
                    <div className="space-y-4">
                      <div className="border-2 border-dashed border-slate-300 rounded-xl p-6 text-center hover:border-primary hover:bg-primary/5 transition-all cursor-pointer">
                        <i className="fa-solid fa-download text-3xl text-slate-400 mb-3 block"></i>
                        <h4 className="font-medium text-slate-800 mb-2">从浏览器导入书签</h4>
                        <p className="text-sm text-slate-500 mb-4">支持 Chrome、Firefox、Safari 等主流浏览器</p>
                        <button 
                          onClick={handleImportBookmarks}
                          className="px-6 py-2 bg-primary text-white rounded-lg hover:bg-primaryHover transition-colors"
                        >
                          开始导入
                        </button>
                      </div>
                      <div className="border-2 border-dashed border-slate-300 rounded-xl p-6 text-center hover:border-primary hover:bg-primary/5 transition-all cursor-pointer">
                        <i className="fa-solid fa-file-import text-3xl text-slate-400 mb-3 block"></i>
                        <h4 className="font-medium text-slate-800 mb-2">从文件导入</h4>
                        <p className="text-sm text-slate-500 mb-4">支持 HTML 书签文件格式</p>
                        <input 
                          type="file" 
                          accept=".html" 
                          onChange={handleFileImport}
                          className="hidden"
                          id="file-import"
                        />
                        <button 
                          onClick={() => document.getElementById('file-import')?.click()}
                          className="px-6 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
                        >
                          选择文件
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* 数据导出 */}
                  <div className={`${styles.glassCard} rounded-2xl p-6`}>
                    <h3 className="text-lg font-semibold text-slate-800 mb-4">数据导出</h3>
                    <div className="space-y-4">
                      <div className="p-4 bg-slate-50 rounded-xl">
                        <h4 className="font-medium text-slate-800 mb-2">导出所有数据</h4>
                        <p className="text-sm text-slate-500 mb-4">包含所有书签、分类和设置信息</p>
                        <button 
                          onClick={handleExportAll}
                          className="px-6 py-2 bg-secondary text-white rounded-lg hover:bg-emerald-600 transition-colors"
                        >
                          <i className="fa-solid fa-download mr-2"></i>
                          导出全部数据
                        </button>
                      </div>
                      <div className="p-4 bg-slate-50 rounded-xl">
                        <h4 className="font-medium text-slate-800 mb-2">仅导出书签</h4>
                        <p className="text-sm text-slate-500 mb-4">导出为标准 HTML 书签格式</p>
                        <button 
                          onClick={handleExportBookmarks}
                          className="px-6 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
                        >
                          <i className="fa-solid fa-bookmark mr-2"></i>
                          导出书签
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 关于 */}
            {currentSetting === 'about' && (
              <div className={styles.settingSection}>
                <div className="mb-8">
                  <h1 className="text-2xl md:text-3xl font-bold text-slate-800 mb-2">关于</h1>
                  <p className="text-slate-500">极简导航 - 您的专属数字空间</p>
                </div>

                <div className="space-y-6">
                  {/* 产品信息 */}
                  <div className={`${styles.glassCard} rounded-2xl p-6`}>
                    <div className="text-center mb-6">
                      <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-primary to-purple-500 flex items-center justify-center text-white shadow-lg mx-auto mb-4">
                        <i className="fa-solid fa-compass text-3xl"></i>
                      </div>
                      <h2 className="text-2xl font-bold text-slate-800 mb-2">极简导航</h2>
                      <p className="text-slate-500">版本 1.0.0</p>
                    </div>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                        <span className="text-slate-600">开发者</span>
                        <span className="font-medium">极简团队</span>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                        <span className="text-slate-600">发布日期</span>
                        <span className="font-medium">2024年10月</span>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                        <span className="text-slate-600">最后更新</span>
                        <span className="font-medium">2024年10月24日</span>
                      </div>
                    </div>
                  </div>

                  {/* 帮助与支持 */}
                  <div className={`${styles.glassCard} rounded-2xl p-6`}>
                    <h3 className="text-lg font-semibold text-slate-800 mb-4">帮助与支持</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <a href="#" className="flex items-center p-4 rounded-xl hover:bg-slate-50 transition-colors group">
                        <div className="w-10 h-10 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center shrink-0">
                          <i className="fa-solid fa-question-circle"></i>
                        </div>
                        <div className="ml-3">
                          <h4 className="font-medium text-slate-800 group-hover:text-primary">帮助文档</h4>
                          <p className="text-sm text-slate-500">查看使用指南</p>
                        </div>
                      </a>
                      <a href="#" className="flex items-center p-4 rounded-xl hover:bg-slate-50 transition-colors group">
                        <div className="w-10 h-10 rounded-lg bg-green-100 text-green-600 flex items-center justify-center shrink-0">
                          <i className="fa-solid fa-comment-dots"></i>
                        </div>
                        <div className="ml-3">
                          <h4 className="font-medium text-slate-800 group-hover:text-primary">反馈建议</h4>
                          <p className="text-sm text-slate-500">联系我们</p>
                        </div>
                      </a>
                      <a href="#" className="flex items-center p-4 rounded-xl hover:bg-slate-50 transition-colors group">
                        <div className="w-10 h-10 rounded-lg bg-purple-100 text-purple-600 flex items-center justify-center shrink-0">
                          <i className="fa-solid fa-bug"></i>
                        </div>
                        <div className="ml-3">
                          <h4 className="font-medium text-slate-800 group-hover:text-primary">问题反馈</h4>
                          <p className="text-sm text-slate-500">报告错误</p>
                        </div>
                      </a>
                      <a href="#" className="flex items-center p-4 rounded-xl hover:bg-slate-50 transition-colors group">
                        <div className="w-10 h-10 rounded-lg bg-orange-100 text-orange-600 flex items-center justify-center shrink-0">
                          <i className="fa-solid fa-star"></i>
                        </div>
                        <div className="ml-3">
                          <h4 className="font-medium text-slate-800 group-hover:text-primary">功能投票</h4>
                          <p className="text-sm text-slate-500">为新功能投票</p>
                        </div>
                      </a>
                    </div>
                  </div>

                  {/* 版权信息 */}
                  <div className={`${styles.glassCard} rounded-2xl p-6 text-center`}>
                    <p className="text-slate-500 mb-2">© 2024 极简导航. 保留所有权利.</p>
                    <div className="flex justify-center space-x-6 text-sm text-slate-400">
                      <a href="#" className="hover:text-primary transition-colors">隐私政策</a>
                      <a href="#" className="hover:text-primary transition-colors">服务条款</a>
                      <a href="#" className="hover:text-primary transition-colors">开源协议</a>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 保存按钮区域 */}
            <div className="mt-8 mb-6">
              <div className="flex justify-end space-x-4">
                <button 
                  onClick={handleCancel}
                  className="px-6 py-3 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors font-medium"
                >
                  取消
                </button>
                <button 
                  onClick={handleSaveSettings}
                  disabled={isLoading}
                  className="px-6 py-3 bg-primary text-white rounded-lg hover:bg-primaryHover transition-colors font-medium shadow-lg shadow-indigo-500/30 disabled:opacity-50"
                >
                  {isLoading ? (
                    <>
                      <i className="fa-solid fa-spinner fa-spin mr-2"></i>
                      保存中...
                    </>
                  ) : (
                    <>
                      <i className="fa-solid fa-save mr-2"></i>
                      保存设置
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* 底部留白 */}
            <div className="h-10"></div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default SettingsPage;

