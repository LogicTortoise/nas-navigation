

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

interface FormData {
  email: string;
  password: string;
  confirmPassword: string;
}

interface FormErrors {
  email: string;
  password: string;
  confirmPassword: string;
}

const RegisterPage: React.FC = () => {
  const navigate = useNavigate();
  
  // 表单数据状态
  const [formData, setFormData] = useState<FormData>({
    email: '',
    password: '',
    confirmPassword: ''
  });

  // 表单错误状态
  const [formErrors, setFormErrors] = useState<FormErrors>({
    email: '',
    password: '',
    confirmPassword: ''
  });

  // UI状态
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);
  const [isConfirmPasswordVisible, setIsConfirmPasswordVisible] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [registerStatus, setRegisterStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [statusMessage, setStatusMessage] = useState('');

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '用户注册 - 极简导航';
    return () => { document.title = originalTitle; };
  }, []);

  // 表单验证函数
  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const validatePassword = (password: string): boolean => {
    return password.length >= 8;
  };

  const validateConfirmPassword = (password: string, confirmPassword: string): boolean => {
    return password === confirmPassword;
  };

  // 显示错误信息
  const showError = (field: keyof FormErrors, message: string) => {
    setFormErrors(prev => ({
      ...prev,
      [field]: message
    }));
  };

  // 隐藏错误信息
  const hideError = (field: keyof FormErrors) => {
    setFormErrors(prev => ({
      ...prev,
      [field]: ''
    }));
  };

  // 显示注册状态
  const showRegisterStatus = (type: 'success' | 'error', message: string) => {
    setRegisterStatus(type);
    setStatusMessage(message);
  };

  // 隐藏注册状态
  const hideRegisterStatus = () => {
    setRegisterStatus('idle');
    setStatusMessage('');
  };

  // 处理输入变化
  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // 处理输入框失去焦点
  const handleInputBlur = (field: keyof FormData) => {
    const value = formData[field];
    
    if (field === 'email' && value) {
      if (!validateEmail(value)) {
        showError('email', '请输入有效的邮箱地址');
      } else {
        hideError('email');
      }
    }
    
    if (field === 'password' && value) {
      if (!validatePassword(value)) {
        showError('password', '密码至少需要8位字符');
      } else {
        hideError('password');
      }
    }
    
    if (field === 'confirmPassword' && value) {
      if (!validateConfirmPassword(formData.password, value)) {
        showError('confirmPassword', '两次输入的密码不一致');
      } else {
        hideError('confirmPassword');
      }
    }
  };

  // 处理表单提交
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // 清除之前的状态
    setFormErrors({
      email: '',
      password: '',
      confirmPassword: ''
    });
    hideRegisterStatus();

    // 获取表单数据
    const { email, password, confirmPassword } = formData;

    // 验证表单
    let isValid = true;

    if (!email) {
      showError('email', '请输入邮箱地址');
      isValid = false;
    } else if (!validateEmail(email)) {
      showError('email', '请输入有效的邮箱地址');
      isValid = false;
    }

    if (!password) {
      showError('password', '请输入密码');
      isValid = false;
    } else if (!validatePassword(password)) {
      showError('password', '密码至少需要8位字符');
      isValid = false;
    }

    if (!confirmPassword) {
      showError('confirmPassword', '请确认密码');
      isValid = false;
    } else if (!validateConfirmPassword(password, confirmPassword)) {
      showError('confirmPassword', '两次输入的密码不一致');
      isValid = false;
    }

    if (!isValid) {
      return;
    }

    // 设置加载状态
    setIsSubmitting(true);

    // 模拟注册请求
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // 模拟注册成功（在实际应用中，这里会发送API请求）
      const isSuccess = Math.random() > 0.1; // 90% 成功率用于演示

      if (isSuccess) {
        showRegisterStatus('success', '注册成功，正在跳转...');
        
        // 2秒后跳转到首页
        setTimeout(() => {
          navigate('/home');
        }, 2000);
      } else {
        showRegisterStatus('error', '注册失败，该邮箱可能已被注册');
        setIsSubmitting(false);
      }
    } catch (error) {
      showRegisterStatus('error', '注册失败，请稍后重试');
      setIsSubmitting(false);
    }
  };

  // 处理密码显示切换
  const handleTogglePassword = () => {
    setIsPasswordVisible(!isPasswordVisible);
  };

  const handleToggleConfirmPassword = () => {
    setIsConfirmPasswordVisible(!isConfirmPasswordVisible);
  };

  // 处理键盘事件
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // ESC键清除错误状态
      if (e.key === 'Escape') {
        setFormErrors({
          email: '',
          password: '',
          confirmPassword: ''
        });
        hideRegisterStatus();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  return (
    <div className={styles.pageWrapper}>
      {/* 背景遮罩，用于提升文字可读性 */}
      <div className="fixed inset-0 bg-gradient-to-br from-indigo-100/30 to-purple-100/30 pointer-events-none z-0"></div>

      {/* 主应用容器 */}
      <div className="relative z-10 w-full max-w-md">
        
        {/* Logo 区域 */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-primary to-purple-500 flex items-center justify-center text-white shadow-lg mx-auto mb-4">
            <i className="fa-solid fa-compass text-2xl"></i>
          </div>
          <h1 className="text-2xl font-bold text-slate-800 mb-2">极简导航</h1>
          <p className="text-slate-500">创建您的专属数字空间</p>
        </div>

        {/* 注册表单卡片 */}
        <div className={`${styles.glassCard} rounded-2xl shadow-2xl p-8`}>
          <div className="text-center mb-6">
            <h2 className="text-xl font-bold text-slate-800 mb-2">用户注册</h2>
            <p className="text-slate-500 text-sm">加入我们，开始高效的导航体验</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            
            {/* 邮箱输入 */}
            <div className="space-y-2">
              <label htmlFor="email" className="block text-sm font-medium text-slate-700">
                <i className="fa-solid fa-envelope mr-2"></i>邮箱地址 *
              </label>
              <input 
                type="email" 
                id="email" 
                name="email" 
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                onBlur={() => handleInputBlur('email')}
                className={`w-full px-4 py-3 rounded-lg border border-slate-300 ${styles.formInputFocus} bg-white/70 backdrop-blur-sm text-slate-800 placeholder-slate-400`}
                placeholder="请输入您的邮箱地址"
                required
              />
              {formErrors.email && (
                <div className={`${styles.errorMessage} ${styles.show}`}>
                  <i className="fa-solid fa-exclamation-circle mr-1"></i>
                  {formErrors.email}
                </div>
              )}
            </div>

            {/* 密码输入 */}
            <div className="space-y-2">
              <label htmlFor="password" className="block text-sm font-medium text-slate-700">
                <i className="fa-solid fa-lock mr-2"></i>密码 *
              </label>
              <div className="relative">
                <input 
                  type={isPasswordVisible ? 'text' : 'password'}
                  id="password" 
                  name="password" 
                  value={formData.password}
                  onChange={(e) => handleInputChange('password', e.target.value)}
                  onBlur={() => handleInputBlur('password')}
                  className={`w-full px-4 py-3 pr-12 rounded-lg border border-slate-300 ${styles.formInputFocus} bg-white/70 backdrop-blur-sm text-slate-800 placeholder-slate-400`}
                  placeholder="请输入密码（至少8位）"
                  minLength={8}
                  required
                />
                <button 
                  type="button" 
                  onClick={handleTogglePassword}
                  className="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-400 hover:text-slate-600"
                >
                  <i className={`fa-solid ${isPasswordVisible ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                </button>
              </div>
              {formErrors.password && (
                <div className={`${styles.errorMessage} ${styles.show}`}>
                  <i className="fa-solid fa-exclamation-circle mr-1"></i>
                  {formErrors.password}
                </div>
              )}
            </div>

            {/* 确认密码输入 */}
            <div className="space-y-2">
              <label htmlFor="confirm-password" className="block text-sm font-medium text-slate-700">
                <i className="fa-solid fa-lock mr-2"></i>确认密码 *
              </label>
              <div className="relative">
                <input 
                  type={isConfirmPasswordVisible ? 'text' : 'password'}
                  id="confirm-password" 
                  name="confirm-password" 
                  value={formData.confirmPassword}
                  onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                  onBlur={() => handleInputBlur('confirmPassword')}
                  className={`w-full px-4 py-3 pr-12 rounded-lg border border-slate-300 ${styles.formInputFocus} bg-white/70 backdrop-blur-sm text-slate-800 placeholder-slate-400`}
                  placeholder="请再次输入密码"
                  required
                />
                <button 
                  type="button" 
                  onClick={handleToggleConfirmPassword}
                  className="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-400 hover:text-slate-600"
                >
                  <i className={`fa-solid ${isConfirmPasswordVisible ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                </button>
              </div>
              {formErrors.confirmPassword && (
                <div className={`${styles.errorMessage} ${styles.show}`}>
                  <i className="fa-solid fa-exclamation-circle mr-1"></i>
                  {formErrors.confirmPassword}
                </div>
              )}
            </div>

            {/* 提交按钮 */}
            <button 
              type="submit" 
              disabled={isSubmitting}
              className={`w-full py-3 px-4 ${styles.btnPrimary} rounded-lg font-medium shadow-lg`}
            >
              <span>{isSubmitting ? '注册中...' : '立即注册'}</span>
              {isSubmitting && (
                <div className={`${styles.loadingSpinner} ${styles.show} ml-2`}></div>
              )}
            </button>

            {/* 注册状态提示 */}
            <div className="text-center">
              {registerStatus === 'success' && (
                <div className={`${styles.successMessage} ${styles.show}`}>
                  <i className="fa-solid fa-check-circle mr-1"></i>
                  {statusMessage}
                </div>
              )}
              {registerStatus === 'error' && (
                <div className={`${styles.errorMessage} ${styles.show}`}>
                  <i className="fa-solid fa-exclamation-circle mr-1"></i>
                  {statusMessage}
                </div>
              )}
            </div>

          </form>

          {/* 登录链接 */}
          <div className="mt-6 text-center">
            <p className="text-slate-500 text-sm">
              已有账户？
              <Link 
                to="/login" 
                className="text-primary hover:text-primaryHover font-medium transition-colors underline underline-offset-4 ml-1"
              >
                立即登录
              </Link>
            </p>
          </div>

        </div>

        {/* 底部版权信息 */}
        <div className="text-center mt-8">
          <p className="text-slate-400 text-xs">
            © 2024 极简导航. 让每一次上网都从这里开始.
          </p>
        </div>

      </div>
    </div>
  );
};

export default RegisterPage;

