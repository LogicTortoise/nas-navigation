

import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import styles from './styles.module.css';

interface FormData {
  url: string;
  name: string;
  category: string;
  icon: string | null;
}

const AddLinkModal: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  
  // 表单状态
  const [formData, setFormData] = useState<FormData>({
    url: '',
    name: '',
    category: '',
    icon: null
  });
  
  // UI状态
  const [showFaviconSection, setShowFaviconSection] = useState(false);
  const [isFaviconLoading, setIsFaviconLoading] = useState(false);
  const [faviconUrl, setFaviconUrl] = useState<string | null>(null);
  const [faviconStatus, setFaviconStatus] = useState('已自动获取网站图标');
  const [selectedIcon, setSelectedIcon] = useState<string | null>(null);
  
  // 引用
  const websiteUrlInputRef = useRef<HTMLInputElement>(null);

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '添加网站链接 - 酷站导航';
    return () => { document.title = originalTitle; };
  }, []);

  // 页面加载时聚焦到URL输入框
  useEffect(() => {
    if (websiteUrlInputRef.current) {
      websiteUrlInputRef.current.focus();
    }
  }, []);

  // 从URL参数获取当前分类
  useEffect(() => {
    const currentCategory = searchParams.get('category');
    if (currentCategory) {
      setFormData(prev => ({ ...prev, category: currentCategory }));
    }
  }, [searchParams]);

  // 关闭弹窗函数
  const handleCloseModal = () => {
    navigate('/home');
  };

  // 显示加载状态
  const showLoading = (element: HTMLElement, text: string = '加载中...') => {
    element.innerHTML = '<i class="fa-solid fa-spinner fa-spin text-slate-400"></i>';
    element.classList.add(styles.faviconLoading);
  };

  // 显示图标
  const showFavicon = (url: string) => {
    const img = document.createElement('img');
    img.src = url;
    img.alt = '网站图标';
    img.className = 'w-8 h-8 object-contain';
    
    img.onload = () => {
      const faviconPreview = document.getElementById('favicon-preview');
      if (faviconPreview) {
        faviconPreview.innerHTML = '';
        faviconPreview.appendChild(img);
        faviconPreview.classList.remove(styles.faviconLoading);
      }
      setFaviconStatus('已自动获取网站图标');
      setFaviconUrl(url);
      setIsFaviconLoading(false);
    };
    
    img.onerror = () => {
      const faviconPreview = document.getElementById('favicon-preview');
      if (faviconPreview) {
        faviconPreview.innerHTML = '<i class="fa-solid fa-globe text-slate-400 text-xl"></i>';
        faviconPreview.classList.remove(styles.faviconLoading);
      }
      setFaviconStatus('无法获取网站图标，使用默认图标');
      setFaviconUrl(null);
      setIsFaviconLoading(false);
    };
  };

  // 尝试获取网站图标
  const fetchFavicon = (url: string) => {
    try {
      const parsedUrl = new URL(url);
      const faviconUrl = `${parsedUrl.protocol}//${parsedUrl.hostname}/favicon.ico`;
      
      setShowFaviconSection(true);
      setIsFaviconLoading(true);
      setFaviconStatus('正在获取网站图标...');
      
      const faviconPreview = document.getElementById('favicon-preview');
      if (faviconPreview) {
        showLoading(faviconPreview);
      }
      
      // 延迟执行以显示加载状态
      setTimeout(() => {
        showFavicon(faviconUrl);
      }, 500);
    } catch (e) {
      console.log('URL解析失败:', e);
    }
  };

  // 表单验证
  const validateForm = (): boolean => {
    const { url, name, category } = formData;
    
    if (!url.trim()) {
      alert('请输入网站URL');
      if (websiteUrlInputRef.current) {
        websiteUrlInputRef.current.focus();
      }
      return false;
    }
    
    if (!name.trim()) {
      alert('请输入网站名称');
      return false;
    }
    
    if (!category) {
      alert('请选择分类');
      return false;
    }
    
    return true;
  };

  // 保存链接
  const handleSaveLink = () => {
    if (!validateForm()) {
      return;
    }
    
    const saveData = {
      ...formData,
      icon: selectedIcon || faviconUrl
    };
    
    console.log('保存链接数据:', saveData);
    
    // 模拟保存成功
    alert('网站链接添加成功！');
    handleCloseModal();
  };

  // URL输入框失焦事件
  const handleUrlBlur = () => {
    const url = formData.url.trim();
    if (url) {
      fetchFavicon(url);
    }
  };

  // 刷新图标
  const handleRefreshFavicon = () => {
    const url = formData.url.trim();
    if (url) {
      fetchFavicon(url);
    }
  };

  // 图标选择
  const handleIconSelect = (icon: string) => {
    setSelectedIcon(icon);
    
    // 如果选择自定义上传
    if (icon === 'custom') {
      console.log('需要调用第三方接口实现文件上传功能');
      // 注释：此功能需要文件上传API，在原型阶段仅做UI展示
    }
  };

  // 表单提交
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSaveLink();
  };

  // 处理输入变化
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // 处理键盘事件
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        handleCloseModal();
      }
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSaveLink();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [formData]);

  // 点击背景关闭弹窗
  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      handleCloseModal();
    }
  };

  const iconOptions = [
    { icon: 'fas fa-globe', label: '地球' },
    { icon: 'fas fa-star', label: '星星' },
    { icon: 'fas fa-heart', label: '爱心' },
    { icon: 'fas fa-lightbulb', label: '灯泡' },
    { icon: 'fas fa-rocket', label: '火箭' },
    { icon: 'custom', label: '上传' }
  ];

  return (
    <div className={styles.pageWrapper}>
      {/* 背景遮罩 */}
      <div className="fixed inset-0 bg-gradient-to-br from-indigo-100/30 to-purple-100/30 pointer-events-none z-0"></div>

      {/* 模态弹窗背景 */}
      <div 
        className={`fixed inset-0 ${styles.modalBackdrop} z-50 flex items-center justify-center p-4`}
        onClick={handleBackdropClick}
      >
        {/* 添加链接弹窗 */}
        <div className={`${styles.glassPanel} rounded-2xl shadow-2xl w-full max-w-md lg:max-w-lg p-6 lg:p-8 ${styles.modalEnter}`}>
          
          {/* 弹窗头部 */}
          <div className="flex justify-between items-center mb-6 lg:mb-8">
            <div className="flex items-center">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-primary to-purple-500 flex items-center justify-center text-white shadow-lg mr-3">
                <i className="fa-solid fa-plus text-lg"></i>
              </div>
              <h3 className="text-xl lg:text-2xl font-bold text-slate-800">添加网站链接</h3>
            </div>
            <button 
              onClick={handleCloseModal}
              className="text-slate-400 hover:text-slate-600 transition-colors p-1 rounded-lg hover:bg-white/50"
            >
              <i className="fa-solid fa-xmark text-xl"></i>
            </button>
          </div>
          
          {/* 表单内容 */}
          <form onSubmit={handleFormSubmit} className="space-y-6">
            
            {/* 网站URL */}
            <div className="space-y-2">
              <label htmlFor="website-url" className="block text-sm font-medium text-slate-700">
                网站 URL <span className="text-accent">*</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <i className="fa-solid fa-link text-slate-400"></i>
                </div>
                <input 
                  type="url" 
                  id="website-url" 
                  name="url"
                  ref={websiteUrlInputRef}
                  value={formData.url}
                  onChange={handleInputChange}
                  onBlur={handleUrlBlur}
                  placeholder="https://example.com" 
                  className={`w-full pl-12 pr-4 py-3 bg-white/80 border border-slate-300 rounded-xl ${styles.formInputFocus} transition-all text-slate-800 placeholder-slate-400`}
                  required
                />
              </div>
              <p className="text-xs text-slate-500">
                输入网址后将自动获取网站图标
              </p>
            </div>

            {/* 网站名称 */}
            <div className="space-y-2">
              <label htmlFor="website-name" className="block text-sm font-medium text-slate-700">
                网站名称 <span className="text-accent">*</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <i className="fa-solid fa-tag text-slate-400"></i>
                </div>
                <input 
                  type="text" 
                  id="website-name" 
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="例如：Google、GitHub" 
                  className={`w-full pl-12 pr-4 py-3 bg-white/80 border border-slate-300 rounded-xl ${styles.formInputFocus} transition-all text-slate-800 placeholder-slate-400`}
                  required
                />
              </div>
            </div>

            {/* 网站图标预览 */}
            {showFaviconSection && (
              <div className="space-y-2">
                <label className="block text-sm font-medium text-slate-700">网站图标</label>
                <div className="flex items-center space-x-4">
                  <div 
                    id="favicon-preview" 
                    className={`w-12 h-12 rounded-lg bg-white shadow-md flex items-center justify-center ${styles.faviconPreview} ${isFaviconLoading ? styles.faviconLoading : ''}`}
                  >
                    <i className="fa-solid fa-globe text-slate-400 text-xl"></i>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-slate-600">{faviconStatus}</p>
                    <button 
                      type="button" 
                      onClick={handleRefreshFavicon}
                      className="text-xs text-primary hover:text-primaryHover transition-colors mt-1"
                    >
                      <i className="fa-solid fa-refresh mr-1"></i>重新获取
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 所属分类 */}
            <div className="space-y-2">
              <label htmlFor="website-category" className="block text-sm font-medium text-slate-700">
                所属分类 <span className="text-accent">*</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <i className="fa-solid fa-folder text-slate-400"></i>
                </div>
                <select 
                  id="website-category" 
                  name="category"
                  value={formData.category}
                  onChange={handleInputChange}
                  className={`w-full pl-12 pr-4 py-3 bg-white/80 border border-slate-300 rounded-xl ${styles.formInputFocus} transition-all text-slate-800 appearance-none`}
                >
                  <option value="">请选择分类</option>
                  <option value="work">工作效率</option>
                  <option value="study">学习充电</option>
                  <option value="design">设计灵感</option>
                  <option value="entertainment">娱乐摸鱼</option>
                </select>
                <div className="absolute inset-y-0 right-0 pr-4 flex items-center pointer-events-none">
                  <i className="fa-solid fa-chevron-down text-slate-400"></i>
                </div>
              </div>
            </div>

            {/* 自定义图标（可选） */}
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700">
                自定义图标 <span className="text-slate-400 text-xs">(可选)</span>
              </label>
              <div className="grid grid-cols-6 gap-3">
                {iconOptions.map((option) => (
                  <button 
                    key={option.icon}
                    type="button" 
                    onClick={() => handleIconSelect(option.icon)}
                    className={`w-12 h-12 rounded-lg bg-white border-2 transition-all flex items-center justify-center ${
                      selectedIcon === option.icon 
                        ? 'border-primary bg-primary/10' 
                        : option.icon === 'custom' 
                          ? 'border-dashed border-slate-300 hover:border-primary hover:shadow-md'
                          : 'border-slate-200 hover:border-primary hover:shadow-md'
                    }`}
                  >
                    {option.icon === 'custom' ? (
                      <i className="fa-solid fa-upload text-slate-400"></i>
                    ) : (
                      <i className={`${option.icon} text-slate-600`}></i>
                    )}
                  </button>
                ))}
              </div>
              <p className="text-xs text-slate-500">选择图标或上传自定义图标</p>
            </div>

            {/* 表单底部操作按钮 */}
            <div className="pt-4 flex space-x-3 lg:space-x-4">
              <button 
                type="button" 
                onClick={handleCloseModal}
                className="flex-1 px-4 py-3 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 font-medium transition-all"
              >
                <i className="fa-solid fa-times mr-2"></i>取消
              </button>
              <button 
                type="submit" 
                onClick={handleSaveLink}
                className="flex-1 px-4 py-3 rounded-xl bg-primary text-white hover:bg-primaryHover font-medium shadow-lg shadow-indigo-500/30 transition-all"
              >
                <i className="fa-solid fa-save mr-2"></i>保存链接
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AddLinkModal;

