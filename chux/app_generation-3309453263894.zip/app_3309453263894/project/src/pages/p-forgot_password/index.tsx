

import { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import styles from './styles.module.css';

interface ForgotPasswordFormData {
  email: string;
}

interface ForgotPasswordFormErrors {
  email: string;
}

export default function ForgotPasswordPage() {
  const navigate = useNavigate();
  const emailInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState<ForgotPasswordFormData>({
    email: ''
  });
  
  const [formErrors, setFormErrors] = useState<ForgotPasswordFormErrors>({
    email: ''
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  // 设置页面标题
  useEffect(() => {
    const originalTitle = document.title;
    document.title = '忘记密码 - 极简导航';
    return () => {
      document.title = originalTitle;
    };
  }, []);

  // 自动聚焦到邮箱输入框
  useEffect(() => {
    if (emailInputRef.current) {
      emailInputRef.current.focus();
    }
  }, []);

  // 键盘事件处理
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // ESC键返回登录页
      if (e.key === 'Escape') {
        navigate('/login');
      }
      
      // Enter键提交表单（当焦点在输入框时）
      if (e.key === 'Enter' && document.activeElement === emailInputRef.current) {
        handleSubmit(e as any);
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [formData, formErrors, isSubmitting, isSubmitted, navigate]);

  // 邮箱验证正则表达式
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  // 邮箱输入验证
  const validateEmail = (email: string): boolean => {
    if (!email) {
      setFormErrors(prev => ({ ...prev, email: '请输入邮箱地址' }));
      return false;
    }
    
    if (!emailRegex.test(email)) {
      setFormErrors(prev => ({ ...prev, email: '请输入有效的邮箱地址' }));
      return false;
    }
    
    setFormErrors(prev => ({ ...prev, email: '' }));
    return true;
  };

  // 处理邮箱输入变化
  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const email = e.target.value.trim();
    setFormData(prev => ({ ...prev, email }));
    validateEmail(email);
  };

  // 处理邮箱失焦
  const handleEmailBlur = () => {
    validateEmail(formData.email.trim());
  };

  // 处理表单提交
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // 验证邮箱
    if (!validateEmail(formData.email.trim())) {
      return;
    }

    // 显示加载状态
    setIsSubmitting(true);

    try {
      // 模拟发送重置链接请求
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // 显示成功状态
      setIsSubmitted(true);
      
      // 3秒后自动跳转到登录页
      setTimeout(() => {
        navigate('/login');
      }, 3000);
    } catch (error) {
      console.error('发送重置链接失败:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className={styles.pageWrapper}>
      {/* 背景遮罩，用于提升文字可读性 */}
      <div className="fixed inset-0 bg-gradient-to-br from-indigo-100/30 to-purple-100/30 pointer-events-none z-0"></div>

      {/* 主容器 */}
      <div className="relative z-10 w-full max-w-md">
        
        {/* Logo 区域 */}
        <div className={`text-center mb-8 ${styles.fadeInUp}`}>
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-tr from-primary to-purple-500 flex items-center justify-center text-white shadow-lg">
            <i className="fa-solid fa-compass text-2xl"></i>
          </div>
          <h1 className="text-2xl font-bold text-slate-800 mb-2">极简导航</h1>
          <p className="text-slate-500">您的专属数字空间</p>
        </div>

        {/* 忘记密码表单卡片 */}
        <div className={`${styles.glassCard} rounded-2xl shadow-2xl p-8 ${styles.fadeInUp}`} style={{ animationDelay: '0.2s' }}>
          
          {/* 表单头部 */}
          <div className="text-center mb-6">
            <h2 className="text-xl font-bold text-slate-800 mb-2">忘记密码</h2>
            <p className="text-slate-500 text-sm">请输入您的注册邮箱，我们将发送重置密码的链接到您的邮箱</p>
          </div>

          {/* 忘记密码表单 */}
          <form onSubmit={handleSubmit} className="space-y-6">
            
            {/* 邮箱输入框 */}
            {!isSubmitted && (
              <div className="space-y-2">
                <label htmlFor="email" className="block text-sm font-medium text-slate-700">
                  <i className="fa-solid fa-envelope mr-2 text-primary"></i>注册邮箱
                </label>
                <input 
                  type="email" 
                  id="email" 
                  name="email" 
                  ref={emailInputRef}
                  value={formData.email}
                  onChange={handleEmailChange}
                  onBlur={handleEmailBlur}
                  disabled={isSubmitting}
                  className={`${styles.formInput} w-full px-4 py-3 rounded-xl text-slate-800 placeholder-slate-400 ${formErrors.email ? styles.errorInput : ''}`}
                  placeholder="请输入您的邮箱地址"
                  required
                />
                {formErrors.email && (
                  <div className={styles.errorMessage}>
                    <i className="fa-solid fa-exclamation-circle mr-1"></i>
                    <span>{formErrors.email}</span>
                  </div>
                )}
              </div>
            )}

            {/* 提交按钮 */}
            {!isSubmitted && !isSubmitting && (
              <button type="submit" className={`${styles.btnPrimary} w-full py-3 rounded-xl font-medium text-lg`}>
                <i className="fa-solid fa-paper-plane mr-2"></i>
                发送重置链接
              </button>
            )}

            {/* 加载状态 */}
            {isSubmitting && (
              <div className="text-center py-3">
                <div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
                <p className="text-slate-500 text-sm mt-2">正在发送重置链接...</p>
              </div>
            )}

            {/* 成功状态 */}
            {isSubmitted && (
              <div className="text-center py-3">
                <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-secondary flex items-center justify-center">
                  <i className="fa-solid fa-check text-white text-xl"></i>
                </div>
                <h3 className="text-lg font-semibold text-slate-800 mb-2">重置链接已发送</h3>
                <p className="text-slate-500 text-sm">请检查您的邮箱并按照说明重置密码</p>
              </div>
            )}

          </form>

          {/* 底部链接 */}
          {!isSubmitted && (
            <div className="mt-8 text-center">
              <Link 
                to="/login" 
                className="inline-flex items-center text-primary hover:text-primaryHover font-medium transition-colors"
              >
                <i className="fa-solid fa-arrow-left mr-2"></i>
                返回登录
              </Link>
            </div>
          )}

        </div>

        {/* 底部版权信息 */}
        <div className={`text-center mt-8 ${styles.fadeInUp}`} style={{ animationDelay: '0.4s' }}>
          <p className="text-slate-400 text-sm">© 2024 极简导航. 保留所有权利.</p>
        </div>

      </div>
    </div>
  );
}

