import { createBrowserRouter, Navigate } from 'react-router-dom';
import { ErrorBoundary } from '../components/ErrorBoundary';

import P_login from '../pages/p-login';
import P_register from '../pages/p-register';
import P_forgot_password from '../pages/p-forgot_password';
import P_home from '../pages/p-home';
import P_settings from '../pages/p-settings';
import P_modal_add_link from '../pages/p-modal_add_link';
import P_modal_edit_link from '../pages/p-modal_edit_link';
import P_modal_add_category from '../pages/p-modal_add_category';
import P_modal_edit_category from '../pages/p-modal_edit_category';
import P_modal_confirm from '../pages/p-modal_confirm';
import NotFoundPage from './NotFoundPage';
import ErrorPage from './ErrorPage';

// 使用 createBrowserRouter 创建路由实例
const router = createBrowserRouter([
  {
    path: '/',
    element: <Navigate to='/login' replace={true} />,
  },
  {
    path: '/login',
    element: (
      <ErrorBoundary>
        <P_login />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
  {
    path: '/register',
    element: (
      <ErrorBoundary>
        <P_register />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
  {
    path: '/forgot-password',
    element: (
      <ErrorBoundary>
        <P_forgot_password />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
  {
    path: '/home',
    element: (
      <ErrorBoundary>
        <P_home />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
  {
    path: '/settings',
    element: (
      <ErrorBoundary>
        <P_settings />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
  {
    path: '/modal-add-link',
    element: (
      <ErrorBoundary>
        <P_modal_add_link />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
  {
    path: '/modal-edit-link',
    element: (
      <ErrorBoundary>
        <P_modal_edit_link />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
  {
    path: '/modal-add-category',
    element: (
      <ErrorBoundary>
        <P_modal_add_category />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
  {
    path: '/modal-edit-category',
    element: (
      <ErrorBoundary>
        <P_modal_edit_category />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
  {
    path: '/modal-confirm',
    element: (
      <ErrorBoundary>
        <P_modal_confirm />
      </ErrorBoundary>
    ),
    errorElement: <ErrorPage />,
  },
  {
    path: '*',
    element: <NotFoundPage />,
  },
]);

export default router;