

/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: '#4F46E5', // Indigo 600
        primaryHover: '#4338ca',
        secondary: '#10B981', // Emerald 500
        accent: '#F43F5E', // Rose 500
        dark: '#1e293b',
        light: '#f8fafc',
        glassBorder: 'rgba(255, 255, 255, 0.2)',
        glassSurface: 'rgba(255, 255, 255, 0.75)',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
      boxShadow: {
        'glass': '0 8px 32px 0 rgba(31, 38, 135, 0.15)',
        'glow': '0 0 15px rgba(79, 70, 229, 0.3)',
      }
    }
  },
  plugins: [],
}

